var nodemailer = require('nodemailer');
const express = require('express')
const hbs = require("nodemailer-express-handlebars");
const bodyParser = require('body-parser');
const fs = require('fs')
const multer = require('multer')
const app = express()
const path_react=require('path')
const path_html_template=require('path')
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path_react.join(__dirname, "/React/sfx-react/build")));
app.use(bodyParser.json())
console.log("hi")
var to="rahulrr29012000@gmail.com";
var subject;
var body;
var client_name;
var client_phone;
var Storage = multer.diskStorage({
    destination: function(req, file, callback) {
        callback(null, "./images");
    },
    filename: function(req, file, callback) {
        callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
    }
});

var upload = multer({
    storage: Storage
}).single("client_file"); //Field name and max count
const handlebarOptions = {
  viewEngine: {
    partialsDir: path_html_template.resolve("./views/"),
    defaultLayout: false,
  },
  viewPath: path_html_template.resolve("./views/"),
};

// use a template file with nodemailer

/*app.get('/',(req,res) => {
    res.sendFile(__dirname + '/React/sfx-react/src/index.js')
})*/
app.get('/', (req, res) => {
  res.sendFile(path_react.join(__dirname, '/React/sfx-react/build', 'index.html'));
});
app.get("/ContactUs", (req, res) => {
  res.sendFile(
    path_react.join(__dirname, "/React/sfx-react/build", "index.html")
  );
});
app.post('/sendemail',(req,res) => {
    upload(req,res,function(err){
        if(err){
            console.log(err)
            return res.end("Something went wrong!");
        }else{
             client_name= req.body.client_name
            subject = req.body.client_query
            client_phone = req.body.client_phone;
            body = req.body.client_query+"<p>Contact Number:"+`${client_phone}`+"</p><p>Name:"+`${client_name}`+"</p>"
            
            path = req.file.path
            console.log(to)
            console.log(subject)
            console.log(body)
            console.log(req.file)
            console.log(req.files)
            var transporter = nodemailer.createTransport({
              service: "gmail",
              auth: {
                user: "rahulsrirampro@gmail.com",
                pass: "xiaedvowmvmcnuhv",
              },
            });
              transporter.use("compile", hbs(handlebarOptions));
              var mailOptions = {
                from: 'rahulsrirampro@gmail.com',
                to: to,
                subject:subject,
                text:body,
                template: 'email',
                context:{
        client_name, // replace {{name}} with Adebola
        client_phone,
      client_query: req.body.client_query 
        // replace {{company}} with My Company
    },
                attachments: [
                  {
                   path: path
                  }
               ]
              };
              
              transporter.sendMail(mailOptions, function(error, info){
                if (error) {
                  console.log(error);
                } else {
                  console.log('Email sent: ' + info.response);
                  fs.unlink(path,function(err){
                    if(err){
                        return res.end(err)
                    }else{
                        console.log("deleted")
                        return res.redirect('/')
                    }
                  })
                }
              });
        }
    })
})

app.listen(5000,() => {
    console.log("App started on Port 5000")
})
