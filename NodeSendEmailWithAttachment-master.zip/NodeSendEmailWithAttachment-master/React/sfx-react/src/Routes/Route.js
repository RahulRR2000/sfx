import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import App from "../App";
import AboutUs from "../Pages/AboutUs/AboutUs";
import ContactUsPage from "../Pages/Contactus/ContactUsPage";
import HomePage from "../Pages/HomePage/HomePage";
const Routes = () => {
  return (
    <div>
      <Router>
        <div>
          <Switch>
            <Route exact path="/" component={HomePage} />
            <Route path="/AboutUs" component={AboutUs} />
            <Route path="/ContactUs" component={ContactUsPage}/>
          </Switch>
        </div>
      </Router>
    </div>
  );
};
export default Routes;
