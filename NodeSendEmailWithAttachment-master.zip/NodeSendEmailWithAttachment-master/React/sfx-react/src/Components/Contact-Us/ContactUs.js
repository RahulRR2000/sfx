import Footer from "../Footer/Footer";
import contactus_img from "../images/contactus-img.svg";
import Navbar from "../Navbar/Navbar";
import address_icon from "../images/address-icon.svg"
import Phone from "../images/Phone.svg";
import email from "../images/email.svg";
import person from "../images/person.svg";
import paperclip from "../images/paperclip.svg";
import info_circle from "../images/info-circle.svg"

const ContactUs = () => {
  return (
    <body class="about-body">
      <Navbar />
      <div class="first-section">
        <div>
          <img class="home-pic" src={contactus_img} alt="" />
        </div>
        <div class="contactUsSvgDiv">
          <svg
            style={{
              position: "absolute !important",
              top: "100px",
              left: "0px",
              right: "0px",
              zIndex: "0",
            }}
            width="100%"
            height="100%"
            version="1.1"
          >
            <circle
              cx="98.5%"
              cy="40%"
              r="290"
              stroke="#D7EFFF"
              fill="#D7EFFF"
              stroke-width="5"
            />
          </svg>
        </div>
        <h2 class="main-heading">
          If you’re interested in collabrating with us,we’d love to hear from
          you.
        </h2>
        <form action="/sendemail" method="POST" enctype="multipart/form-data">
          <div
            style={{
              width: "32%",
              border: "0.4px solid #49ABE1",
              boxSizing: "border-box",

              borderRadius: "2px",
            }}
            class="input-group mb-3"
          >
            <span
              style={{ backgroundColor: "white" }}
              class="input-group-text"
              id="basic-addon1"
            >
              <img alt="" src={person} />
            </span>
            <input
              style={{ borderLeft: "0px" }}
              name="client_name"
              id="client_name"
              type="text"
              class="form-control"
              placeholder="Username"
              aria-label="Username"
              aria-describedby="basic-addon1"
              required
            />
          </div>
          <div
            style={{
              width: "32%",
              border: "0.4px solid #49ABE1",
              boxSizing: "border-box",
              borderRadius: "2px",
              backgroundColor: "white",
            }}
            class="input-group mb-3"
          >
            <span
              style={{
                backgroundColor: "white",
                position: "relative",
                top: "4spx",
                border: "0px",
                right: "0px",
                height: "50px",
              }}
              class="input-group-text"
              id="basic-addon1"
            >
              <img alt="" style={{ opacity: "3.5" }} src={info_circle} />
            </span>
            <textarea
              style={{ resize: "none", border: "0px", color: "#323232" }}
              rows="4"
              cols="20"
              placeholder="Your Query"
              name="client_query"
              id="client_query"
              class="form-control"
            ></textarea>
          </div>
          <div
            style={{
              width: "32%",
              border: "0.4px solid #49ABE1",
              boxSizing: "border-box",

              borderRadius: "2px",
            }}
            class="input-group mb-3"
          >
            <span
              style={{ backgroundColor: "white" }}
              class="input-group-text"
              id="basic-addon1"
            >
              <img alt="" src={Phone} />
            </span>
            <input
              style={{ borderLeft: "0px" }}
              name="client_phone"
              id="client_phone"
              type="text"
              class="form-control"
              placeholder="Phone number"
              aria-label="Username"
              aria-describedby="basic-addon1"
            />
          </div>
          <div
            style={{
              width: "32%",
              border: "0.4px solid #49ABE1",
              boxSizing: "border-box",

              borderRadius: "2px",
            }}
            class="input-group mb-3"
          >
            <span
              style={{ backgroundColor: "white" }}
              class="input-group-text"
              id="basic-addon1"
            >
              <img alt="" style={{ opacity: "3.5" }} src={email} />
            </span>
            <input
              style={{ borderLeft: "0px" }}
              name="client_email"
              id="client_email"
              type="text"
              class="form-control"
              placeholder="Email"
              aria-label="Username"
              aria-describedby="basic-addon1"
            />
            
          </div>
          <div
            style={{
              width: "32%",
              border: "0.4px solid #49ABE1",
              boxSizing: "border-box",

              borderRadius: "2px",
            }}
            class="input-group mb-3"
          >
            <span
              style={{ backgroundColor: "white" }}
              class="input-group-text"
              id="basic-addon1"
            >
              <img alt="" style={{ opacity: "3.5" }} src={paperclip} />
            </span>
            <input
              style={{ borderLeft: "0px" }}
              name="client_file"
              id="client_file"
              type="file"
              class="form-control"
              placeholder="file"
              aria-label="Username"
              aria-describedby="basic-addon1"
            />
            <input style={{backgroundColor: "#236c95", borderRadius: "2%", color: "white"}} type="submit" />
          </div>
        </form>
      </div>
      <div style={{ position: "relative", top: "200px" }}>
        <Footer />
      </div>
    </body>
  );
};
export default ContactUs;