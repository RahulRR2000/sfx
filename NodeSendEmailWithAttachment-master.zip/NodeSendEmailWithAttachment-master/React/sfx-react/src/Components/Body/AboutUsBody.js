import Navbar from "../Navbar/Navbar";
import workgallery from "../images/work-gallery.png"
import workgallery2 from "../images/work-gallery2.png";
import workgallery3 from "../images/work-gallery3.png";
import workgallery4 from "../images/work-gallery4.png";
import workgallery5 from "../images/work-gallery5.png";
import workgallery6 from "../images/work-gallery6.png";
import workgallery7 from "../images/work-gallery7.png"
import workgallery8 from "../images/work-gallery8.png";
import leftarrow from "../images/left-arrow.png";
import rightarrow from "../images/right-arrow.png";
const AboutUsBody = () => {
  return (
    <body class="about-body">
      <Navbar />
      <p class="all-about">All About Us</p>
      <div class="para-text">
        <p>
          Quis ut erat malesuada ut quis urna, mattis adipiscing. Convallis nam
          eget donec ac feugiat amet tortor metus. Venenatis, velit lorem eget
          sit tempor justo, scelerisque aenean massa. Egestas eu vestibulum
          magna proin sit malesuada facilisi. Id scelerisque morbi massa dui.
        </p>
        <p>
          Vel eget diam amet ornare enim adipiscing sem. Pulvinar et magna
          condimentum hendrerit gravida interdum iaculis semper. Volutpat sit
          vitae nec sed pharetra nisi lobortis ultricies sed. Eu cursus mi
          malesuada pulvinar dictumst arcu. Varius massa nullam ullamcorper
          rhoncus tristique velit auctor vitae suspendisse. Mattis dignissim sed
          suscipit pellentesque tincidunt mi, venenatis, orci. Nulla nec congue
          vestibulum, morbi arcu sed eget.
        </p>
        <p>
          Nunc ut sem egestas id in tristique sed at. Accumsan quam habitasse
          sit et elit velit aliquam. Turpis mi feugiat tortor sapien, netus. A
          magna sit in rhoncus purus enim, quam imperdiet egestas. Posuere augue
          amet morbi id habitant magna faucibus. Aliquam sollicitudin morbi odio
          amet, volutpat dui. Enim ac, gravida ullamcorper fames amet
          consectetur non, nulla turpis. Cras sed arcu, volutpat enim turpis
          tristique viverra ac turpis. Massa massa mattis tincidunt ullamcorper
          fringilla lacus in sed. Semper ut leo nunc.
        </p>
      </div>
      <p class="work-gallery">Work Gallery</p>

      <div class="gallery-container">
        <div
          id="carouselExampleIndicators"
          style={{ position: "relative", bottom: "60px" }}
          class="carousel slide"
          data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item about-us-carousel-item active">
              <div class="row">
                <img alt="" class="col-md-3" src={workgallery} />
                <img class="col-md-3" src={workgallery2} alt="" />
                <img class="col-md-3" src={workgallery3} alt="" />
                <img class="col-md-3" src={workgallery4} alt="" />
              </div>
              <div class="row">
                <img class="col-md-3" src={workgallery5} alt="" />
                <img class="col-md-3" src={workgallery6} alt="" />
                <img class="col-md-3" src={workgallery7} alt="" />
                <img class="col-md-3" src={workgallery8} alt="" />
              </div>
            </div>

            <div class="carousel-item about-us-carousel-item">
              <div class="row">
                <img alt="" class="col-md-3" src={workgallery} />
                <img class="col-md-3" src={workgallery2} alt="" />
                <img class="col-md-3" src={workgallery3} alt="" />
                <img class="col-md-3" src={workgallery4} alt="" />
              </div>
              <div class="row">
                <img class="col-md-3" src={workgallery5} alt="" />
                <img class="col-md-3" src={workgallery6} alt="" />
                <img class="col-md-3" src={workgallery7} alt="" />
                <img class="col-md-3" src={workgallery8} alt="" />
              </div>
            </div>

            <div class="carousel-item about-us-carousel-item">
              <div class="row">
                <img alt="" class="col-md-3" src={workgallery} />
                <img class="col-md-3" src={workgallery2} alt="" />
                <img class="col-md-3" src={workgallery3} alt="" />
                <img class="col-md-3" src={workgallery4} alt="" />
              </div>
              <div class="row">
                <img class="col-md-3" src={workgallery5} alt="" />
                <img class="col-md-3" src={workgallery6} alt="" />
                <img class="col-md-3" src={workgallery7} alt="" />
                <img class="col-md-3" src={workgallery8} alt="" />
              </div>
          </div>
        </div>
        </div>
        <button
          class="carousel-control-prev "
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="prev"
        >
          <span class="carousel-control-prev-icon" aria-hidden="true">
            <img src={leftarrow} alt="" />
          </span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button
          class="carousel-control-next"
          style={{ height: "30px !important" }}
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="next"
        >
          <span
            class="carousel-control-next-icon"
            style={{
              position: "relative !important",
              top: "188px",
             left: "20px"
            }}
            aria-hidden="true"
          >
            <img src={rightarrow} alt="" />
          </span>

          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </body>
  );
};
export default AboutUsBody;
