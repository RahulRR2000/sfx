import Navbar from "../Navbar/Navbar"
import logo2 from "../images/logo2.png"
import Ellipse_24 from "../images/Ellipse 24.png";
import home2 from "../images/home2.png";
import info2 from "../images/info2.png";
import telegram from "../images/telegram.png";
import homepic from "../images/homepic.png";
import ellipse_homepic from "../images/ellipse-homepic.png";
import arrow from "../images/arrow.svg";
import triangle_square from "../images/triangle-square.png";
import ourjourney_first from "../images/ourjourney-first.png";
import ourjourney_2nd from "../images/ourjourney-2nd.png";
import ourjourney_3rd from "../images/ourjourney-3rd.png";
import ourjourney_4th from "../images/ourjourney-4th.png";
import oval_specialized from "../images/oval-specialized.svg";
import oval_specialized2 from "../images/oval-specialized2.svg";
import specialized_icon from "../images/specialized-icon.svg";
import spiral_specialized_section from "../images/spiral-specialized-section.svg";
import achievements_img1_1 from "../images/achievements-img1(1).svg";
import achievements_img1_2 from "../images/achievements-img1(2).svg";
import achievements_img1_3 from "../images/achievements-img1 (3).svg";
import achievements_img1_4 from "../images/achievements-img1 (4).svg";
import achievements_icon from "../images/achievements-icon.svg"
import spiral2 from "../images/spiral2.svg";
import spiral3 from "../images/spiral3.svg";
import spiral4 from "../images/spiral4.svg";
import spiral5 from "../images/spiral5.svg";

import clientsHeadingIcon from "../images/clients-heading-icon.svg"
import weArePleasedToWorkWith from "../images/We Are Pleased To Work With.svg";
import xiomiPreview from "../images/Xiaomi-removebg-preview 1.svg";
import samsung from "../images/Samsung 1.svg";
import nokiaPreview from "../images/Nokia-removebg-preview 1.svg";
import airtel from "../images/Airtel-removebg-preview 1.svg";
const Home=()=>{
return (
  <body class="aboutus-body">
    <Navbar />
    <div class="first-section">
      <div>
        <img class="home-pic" src={homepic} alt="" />
      </div>
      <div>
        <svg style={{ position: "absolute !important", top: "-20px", left: "0px", right: "0px", zIndex: "0"}} width="100%" height="100%" version="1.1">
          <circle
            cx="96.5%"
            cy="40%"
            r="400"
            stroke="#D7EFFF"
            fill="#D7EFFF"
            stroke-width="5"
          />
        </svg>
      </div>
      <h2 class="main-heading">Ipsum reprehenderit consequat ut deserunt.</h2>
      <p class="heading-para">
        Irure ex sit aliquip cupidatat magna proident aliquip exercitation
        pariatur. Ex incididunt qui commodo culpa sit adipisicing labore magna.
        Ad aute officia quis ea ut.
      </p>
    </div>
    <section class="container-section" style={{overflowX: "clip"}}>
      <img class="arrow-img1" src={arrow} alt="" />
      <img class="arrow-img2" src={arrow} alt="" />
      <img class="arrow-img3" src={arrow} alt="" />
      <div class="container" style={{ marginRight: "0% !important" }}>
        <div class="section-2-heading">
          <img
            style={{ width: "39px", height: "54px", display: "inline-block" }}
            src={triangle_square}
            alt=""
          />
          <h2 style={{ color: "#236C95", display: "inline-block" }}>
            Our Journey
          </h2>
        </div>
        <div class="first">
          <img src={ourjourney_first} alt="" />
          <h3>Fabrication Even Before Exisiting Of Digital Printing</h3>
          <p>
            Irure ex sit aliquip cupidatat magna proident aliquip exercitation
            pariatur. Ex incididunt qui commodo culpa sit adipisicing labore
            magna. Ad aute officia quis ea ut.
          </p>
        </div>
        <div class="second">
          <img src={ourjourney_2nd} alt="" />
          <h3>Venturing Into Best & Latest Technologies</h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
            ornare eu libero sit et adipiscing nunc. Mauris fusce et commodo id.
            Quam venenatis in eget quis. Sed urna arcu sit in. Blandit ut
            ullamcorper.
          </p>
        </div>
        <div class="third">
          <img src={ourjourney_3rd} alt="" />
          <h3>Infrastructural Growth & Team Strength</h3>
          <p>
            Ultricies ut erat ullamcorper fringilla commodo duis dictum. Amet
            non, purus magnis eget porttitor est eget ut. Odio sollicitudin
            platea proin ut mi eu. Porta convallis volutpat, maecenas
            pellentesque in a.{" "}
          </p>
        </div>
        <div class="fourth">
          <img src={ourjourney_4th} alt="" />
          <h3>Employee Power & Resource Base</h3>
          <p>
            Mauris odio nec turpis aliquam. Dictumst platea pellentesque tortor
            porttitor congue. Odio id vehicula mattis bibendum sodales
            sollicitudin metus. Purus placerat vitae id a vitae vulputate amet.
          </p>
        </div>
      </div>
    </section>
    <section class="specialized-section">
      <img class="oval1" src={oval_specialized} alt="" />
      <img class="oval2" src={oval_specialized2} alt="" />
      <div class="heading">
        <img
          style={{ width: "34px", height: "38px" }}
          src={specialized_icon}
          alt=""
        />
        <h2>What Are We Specialized Into</h2>
      </div>
      <div class="specialized-info">
        <span>
          <img
            style={{ width: "30px", height: "31px", marginRight: "2%" }}
            src={spiral_specialized_section}
            alt=""
          />
          Vinyl Cutting and Digital Signages{" "}
        </span>
        <span>
          <img
            style={{ width: "30px", height: "31px", marginRight: "2%" }}
            src={spiral2}
            alt=""
          />
          Digital Printing{" "}
        </span>
        <span>
          <img
            style={{ width: "30px", height: "31px", marginRight: "2%" }}
            src={spiral3}
            alt=""
          />
          ACP with Acrylic Cut Outs &amp; Projection Displays{" "}
        </span>
        <span>
          <img
            style={{ width: "30px", height: "31px", marginRight: "2%" }}
            src={spiral4}
            alt=""
          />
          Acrylic Sandwitch Displayes &amp; Profile Standees{" "}
        </span>
        <span>
          <img
            style={{ width: "30px", height: "31px", marginRight: "2%" }}
            src={spiral5}
            alt=""
          />
          ALCO Panel LED Board & Edge to Edge Signage{" "}
        </span>
      </div>
    </section>
    <section class="about-md-section">
      <div class="heading">
        <span>
          <img src="./images/Our-vision-icon.svg" alt="" />
        </span>
        <span class="vision-img">
          <img src="./images/Our Vision (1).svg" alt="" />
        </span>
      </div>
      <div id="about-md">
        <div class="quotes">
          <div class="img">
            <img src="./images/quotes.svg" alt="" />
            <img src="./images/quotes.svg" alt="" />
          </div>
          <p>
            Dui tortor viverra porttitor vitae egestas vel morbi massa, vitae.
            Quisque in accumsan, integer orci adipiscing. Nec, nam tempus
            adipiscing vulputate vitae suspendisse diam. Quis nunc, diam
            convallis sagittis. Vestibulum donec habitasse mattis odio odio
            dolor amet. Morbi ultrices rutrum id dui nunc enim tincidunt. Ac
            habitant morbi rhoncus sapien tempus neque sit eget. Viverra
            vulputate arcu, eget adipiscing amet. Id diam habitasse.
          </p>
        </div>

        <hr
          style={{
            position: "relative",
            left: "900px",
            top: "50px",
            transform: "rotate(90deg)",
            width: "150px",
          }}
        />

        <figure>
          <img
            style={{ position: "relative", left: "69px", bottom: "20px" }}
            src="./images/profile-pic.svg"
            alt=""
          />
          <figcaption style={{ textAlign: "center" }}>R S Ramesh</figcaption>
          <figcaption style={{ textAlign: "center" }}>
            MD, Special FX Solutions PVT Limited
          </figcaption>
        </figure>
      </div>
    </section>

    <section class="achievement-section">
      <h2>
        {" "}
        <span>
          <img src={achievements_icon} alt="" />
        </span>
        Achievements Gallery
      </h2>
      <div
        id="carouselExampleIndicators"
        class="carousel slide"
        data-bs-ride="carousel"
      >
        <div class="carousel-indicators">
          <span class="first">
            <button
              type="button"
              style={{
                borderRadius: "22px !important",
                width: "12px !important",
                height: "11px !important",
              }}
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide-to="0"
              class="active"
              aria-current="true"
              aria-label="Slide 1"
            ></button>
          </span>
          <span class="second">
            <button
              type="button"
              style={{
                borderRadius: "22px !important",
                width: "12px !important",
                height: "11px !important",
              }}
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide-to="1"
              aria-label="Slide 2"
            ></button>
          </span>
          <span class="third">
            <button
              type="button"
              style={{
                borderRadius: "22px !important",
                width: "12px !important",
                height: "11px !important",
              }}
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide-to="2"
              aria-label="Slide 3"
            ></button>
          </span>
        </div>

        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="row">
              <div>
                <img class="col-md-6 img" src={achievements_img1_4} alt="" />
                <img class="col-md-3 img" src={achievements_img1_3} alt="" />
              </div>
            </div>
            <div class="row">
              <div>
                <img class="col-md-3 img" src={achievements_img1_2} alt="" />
                <img class="col-md-6 img" src={achievements_img1_1} alt="" />
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="row">
              <div>
                <img class="col-md-6" src={achievements_img1_4} alt="" />
                <img class="col-md-3" src={achievements_img1_2} alt="" />
              </div>
            </div>
            <div class="row">
              <div>
                <img class="col-md-3" src={achievements_img1_3} alt="" />
                <img class="col-md-6" src={achievements_img1_1} alt="" />
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="row">
              <div>
                <img class="col-md-6" src={achievements_img1_4} alt="" />
                <img class="col-md-3" src={achievements_img1_2} alt="" />
              </div>
            </div>
            <div class="row">
              <div>
                <img class="col-md-3" src={achievements_img1_3} alt="" />
                <img class="col-md-6" src={achievements_img1_1} alt="" />
              </div>
            </div>
          </div>
        </div>
        <button
          class="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="prev"
        >
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button
          class="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="next"
        >
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </section>
    <section class="clients-section">
      <div class="heading">
        <img src={clientsHeadingIcon} alt="" />
      </div>
      <div class="clients-grid">
        <div>
          <span>
            <img src={weArePleasedToWorkWith} alt="" />
          </span>
        </div>
        <img
          class="client"
          src={xiomiPreview}
          alt=""
        />
        <hr />
        <img class="client" src={samsung} alt="" />
        <hr />
        <img
          class="client"
          src={airtel}
          alt=""
        />
        <hr />
        <img
          class="client"
          src={nokiaPreview}
          alt=""
        />
      </div>
    </section>
  </body>
);
}
export default Home;