import fb from "../images/fb.png";
import insta from "../images/insta.png";
import phone from "../images/phone.png";
import envelope from "../images/Envelope.png";
const Footer = () => {
  return (
    <footer class="footer">
      <div class="main-div">
        <div style={{ marginBottom: "5%" }} class="fb-btn-div">
          <a href="#" class="fb-btn">
            <img alt="" src={fb} />
          </a>
          <a class="insta-btn" href="#">
            <img alt="" src={insta} />
          </a>
        </div>

        <div style={{ marginBottom: "5%" }}>
          <a style={{ textDecoration: "none" }} href="#">
            <span
              style={{
                width: "69px",
                height: "19px",
                marginRight: "4%",
                color: "white !important",
              }}
            >
              About Us
            </span>
          </a>
          <a style={{ textDecoration: "none" }} href="#">
            <span
              style={{
                color: "white !important",
                width: "79px",
                height: "19px",
              }}
            >
              Contact Us
            </span>
          </a>
        </div>

        <div style={{ marginBottom: "5%" }}>
          <img
            alt=""
            style={{
              width: "13.63px",
              height: "13.63px",
              marginRight: "2%",
              position: "relative",
              top: "1px",
            }}
            src={phone}
          />
          <span style={{width: "83px", height: "16px"}}>9840574954</span>
        </div>

        <div style={{ marginBottom: "5%" }}>
          <img
            alt=""
            style={{
              width: "17.75px",
              height: "17.71px",
              marginRight: "2%",
              position: "relative",
              top: "3px",
            }}
            src={envelope}
          />
          <span style={{ width: "185px", height: "21px" }}>
            specialfxsolution@gmail.com
          </span>
        </div>
        <hr style={{ width: "400px"}} />
        <div>
          &copy;&nbsp;Special FX Solutions PVT LTD | All rights reserved
        </div>
      </div>
    </footer>
  );
};
export default Footer;
