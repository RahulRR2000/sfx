import logo2 from "../images/logo2.png";
import home2 from "../images/home2.png";
import ellipse_24 from "../images/Ellipse 24.png";
import info2 from "../images/info2.png";
import telegram from "../images/telegram.png";
import { NavLink } from "react-router-dom";
import { useHistory } from "react-router-dom";
const Navbar = () => {
  const router = useHistory();
  const location=router.location.pathname;
  console.log("entered nav");
  const contactUsHandler = (e) => {
  
    router.push("/AboutUs");
  };
  console.log("location:",router.location.pathname)
  return (
    <nav>
      <div>
        <img class="logo" src={logo2} alt="" />
      </div>
      <img class="ellipse" src={ellipse_24} alt="" />

      <ul class="nav-right">
        {location === "/" && (
          <div style={{ backgroundColor: "#FFFFFF" }} class="button-nav">
               <div class="aboutus-div">
            <img class="home-img" src={home2} alt="" />
            <div class="li-tag">
              <li class="li-tag">
                <NavLink
                  style={{ color: "#236C95", textDecoration: "none" }}
                  to="/"
                >
                  Home
                </NavLink>
              </li>
            </div>
            </div>
          </div>
        )}
        {location !== "/" && (
          <>
            <img class="home-img" src={home2} alt="" />
            <div class="li-tag">
              <li class="li-tag">
                <NavLink
                  style={{ color: "#236C95", textDecoration: "none" }}
                  to="/"
                >
                  Home
                </NavLink>
              </li>
            </div>
          </>
        )}
        {location === "/AboutUs" && (
          <div style={{ backgroundColor: "#FFFFFF" }} class="button-nav">
            <div class="aboutus-div">
              <img class="about-img" src={info2} alt="" />
              <div>
                <li class="li-tag">
                  <NavLink
                    style={{ color: "#236C95", textDecoration: "none" }}
                    to="/AboutUs"
                  >
                    About Us
                  </NavLink>
                </li>
              </div>
            </div>
          </div>
        )}
        {location !== "/AboutUs" && (
          <div class="aboutus-div">
            <img class="about-img" src={info2} alt="" />
            <div>
              <li class="li-tag">
                <NavLink
                  style={{ color: "#236C95", textDecoration: "none" }}
                  to="/AboutUs"
                >
                  About Us
                </NavLink>
              </li>
            </div>
          </div>
        )}
        {location === "/ContactUs" && (
          <div style={{ backgroundColor: "#FFFFFF" }} class="button-nav">
               <div class="aboutus-div">
            <img class="contact-img" src={telegram} alt="" />
            <div>
              <li class="last-item-nav li-tag">
                {" "}
                <NavLink
                  style={{ color: "#236C95", textDecoration: "none" }}
                  to="/ContactUs"
                >
                  Contact Us
                </NavLink>
              </li>
            </div>
            </div>
          </div>
        )}
        {location !== "/ContactUs" && (
            <>
            <img class="contact-img" src={telegram} alt="" />
            <div>
              <li class="last-item-nav li-tag">
                {" "}
                <NavLink
                  style={{ color: "#236C95", textDecoration: "none" }}
                  to="/ContactUs"
                >
                  Contact Us
                </NavLink>
              </li>
            </div>
            </>
        
        )}
      </ul>
    </nav>
  );
};
export default Navbar;
