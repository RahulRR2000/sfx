import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Footer from './Components/Footer/Footer';
import AboutUsBody from './Components/Body/AboutUsBody';
import Home from './Components/Home/Home';
function App() {
  return (
    <div >

<Home/>
<div style={{position: "relative",top: "1200px"}}>
<Footer/>
</div>
    </div>
  );
}


export default App;
