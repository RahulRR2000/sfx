import Home from "../../Components/Home/Home"
import Footer from "../../Components/Footer/Footer"
const HomePage=()=>{
    return (
      <div>
        <Home />
        <div style={{ position: "relative", top: "1200px" }}>
          <Footer />
        </div>
        
      </div>
    );
}
export default HomePage;