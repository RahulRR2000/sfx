import ContactUs from "../../Components/Contact-Us/ContactUs"
const ContactUsPage=()=>{
    return(

            <ContactUs/>

        
    )
}
export default ContactUsPage;