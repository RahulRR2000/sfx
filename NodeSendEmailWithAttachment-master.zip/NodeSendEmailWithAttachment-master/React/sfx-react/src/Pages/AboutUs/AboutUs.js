import AboutUsBody from "../../Components/Body/AboutUsBody"
import ContactUs from "../../Components/Contact-Us/ContactUs";
import Footer from "../../Components/Footer/Footer"

const AboutUs=()=>{
return(
    <div>
    <AboutUsBody/>
    <Footer/>


    </div>
    
)
}
export default AboutUs;