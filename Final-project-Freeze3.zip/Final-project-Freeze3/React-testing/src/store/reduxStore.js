//import {createStore} from 'redux';
import { createSlice, configureStore } from '@reduxjs/toolkit';
const initialProductSpecificationState = {
  product_title: "",
  product_category: "",
  product_price: 0,
  product_description: "",
  product_manufacturedBy: "",
  product_image: "",
  product_flag: 0,
};
const initialReviewsState={
  reviews: [],
  show: false
}
const initialRecepientDetailsState={
  firstName: "",
  lastName: "",
  address: "",
  phoneNumber: ""
};
const initialUserState = {
  username: "",
  password: "",
  phoneNumber: "",
  email: "",
  cart: [],
  orders: [],
  wishes: [],
};
const initialtotalPriceState={
  totalPrice: 0
}
const initialCardValidationState={
valid: false
}
const cardValidationSlice=createSlice({
name: "cardValidation",
initialState: initialCardValidationState,
reducers: {
  setValid(state)
  {
    state.valid=!state.valid
  }
}
}
)
const recepientDetailsSlice=createSlice({
name: "recepientDetails",
initialState: initialRecepientDetailsState,
reducers: {
  setFirstName(state,action)
  {
    state.firstName=action.payload
  },
  setLastName(state,action)
  {
    state.lastName=action.payload
  },
  setAddress(state,action)
  {
    state.address=action.payload
  },
  setPhoneNumber(state,action)
  {
    state.phoneNumber=action.payload;
  },
  

}
}
)
const totalPriceSlice = createSlice({
  name: "totalPrice",
  initialState: initialtotalPriceState,
  reducers: {
   setTotalPrice(state,action)
   {
     state.totalPrice= action.payload
   }
  },
});
const initialCounterState={
  counter: 0
}
const counterSlice=createSlice({
  name: 'counterDetails',
  initialState: initialCounterState,
  reducers: {
    setCounter(state)
    {
      state.counter=state.counter+1
    }
  }
})
const userSlice = createSlice({
  name: 'userDetails',
  initialState: initialUserState,
  reducers: {
    setUsername(state,action) {
      state.username=action.payload;
    },
    setPassword(state,action) {
      state.password=action.payload;
    },
    setPhoneNumber(state, action) {
      state.phoneNumber = action.payload;
    },
    setEmail(state,action) {
      state.email=action.payload
    },
    setCart(state,action) {
      state.cart = action.payload;
    },
    setOrder(state,action)
    {
     state.orders=action.payload 
    },
    setWishes(state,action)
    {
      state.wishes=action.payload
    },
    clearAllData(state)
  {
    state.username="";
    state.password="";
    state.phoneNumber="";
    state.email="";
    state.cart=[];
    state.orders=[];
    state.wishes=[];
  }
  },
});
const reviewsSlice=createSlice({
  name: 'reviews',
  initialState: initialReviewsState,
  reducers: {
    setReviews(state,action)
    {
      state.reviews=action.payload
    },
    setShow(state,action)
    {
      state.show=action.payload
    }
  }
})

const initialAuthState = {
  isAuthenticated: false
};

const authSlice = createSlice({
  name: 'authentication',
  initialState: initialAuthState,
  reducers: {
    login(state) {
      state.isAuthenticated = true;
    },    logout(state) {
      state.isAuthenticated = false;
    },
  },
});


const initialProductsState={
  products: [],
  wellnessProducts: [],
  medicineProducts: [],
  beautyProducts: [],
  quantity: '',
  flag: 0

}
 
const productSlice= createSlice({
  name: 'products',
  initialState: initialProductsState,
  reducers: {
    setProducts(state,action){
        state.products = action.payload       
    },
    setWellnessProducts(state,action)
    {
      state.wellnessProducts= action.payload
    },
    setMedicineProducts(state,action)
    {
      state.medicineProducts= action.payload
    },
    setBeautyProducts(state,action)
    {
      state.beautyProducts = action.payload
    },
    setFlag(state)
    {
      state.flag=!state.flag
    },
    setQuantity(state)
    {
      state.quantity=state.quantity+1
    }
  }

})

 const productSpecificationSlice = createSlice({
   name: "productSpecification",
   initialState: initialProductSpecificationState,
   reducers: {
     setProduct_title(state, action) {
       state.product_title = action.payload;
     },
     setProduct_category(state, action) {
       state.product_category = action.payload;
     },
     setProduct_price(state, action) {
       state.product_price = action.payload;
     },
     setProduct_description(state, action) {
       state.product_description = action.payload;
     },
     setProduct_manufacturedBy(state, action) {
       state.product_manufacturedBy = action.payload;
     },
     setProduct_flag(state) {
       state.product_flag = !state.product_flag;
     },
     setProduct_image(state, action) {
       state.product_image = action.payload;
     },
   },
 });
const store = configureStore({
  reducer: {
    userDetails: userSlice.reducer,
    authentication: authSlice.reducer,
    products: productSlice.reducer,
    productSpecification: productSpecificationSlice.reducer, 
    totalPrice: totalPriceSlice.reducer,
    counterDetails: counterSlice.reducer,
    cardValidation: cardValidationSlice.reducer,
    recepientDetails: recepientDetailsSlice.reducer,
    reviews: reviewsSlice.reducer
  },
});
export const cardValidationActions= cardValidationSlice.actions;
export const counterActions= counterSlice.actions;
export const userActions = userSlice.actions;
export const authActions = authSlice.actions;
export const productActions=productSlice.actions;
export const productSpecificationActions=productSpecificationSlice.actions;
export const totalPriceActions=totalPriceSlice.actions;
export const recepientDetailsActions=recepientDetailsSlice.actions;
export const reviewsActions= reviewsSlice.actions;
export default store;