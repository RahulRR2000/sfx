import axios from 'axios';
import './cartPage.css'
import { useSelector,useDispatch } from 'react-redux';
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'
import { productActions, userActions } from "../../store/reduxStore";
import {useHistory} from 'react-router-dom'
import { useState } from 'react';
import { totalPriceActions } from '../../store/reduxStore';
const CartPage=()=>{
  let cart = useSelector((state) => state.userDetails.cart);
 const [flag,setFlag]=useState(0)
 let total=cart.length;
    console.log("updated ",cart)
let totalprice=useSelector((state)=>state.totalPrice.totalPrice)
const router=useHistory();
const dispatch=useDispatch();
cart.map((cart) => (
totalprice+=cart.price

))

 const username=useSelector((state)=>state.userDetails.username)
 const checkoutHandler=() => {
  
  router.push("/Payment");
}
 const deleteCartItem=(product,id)=>{
   let data={
     username,
     product: product
   }
axios.delete(`http://localhost:3004/api/deleteCartItem/${id}`,{data})
.then((response)=>{
  if(response.data.status==='success')
  {
    console.log("delete success")
    
   //  dispatch(userActions.setCart(response.data.data.cart));
   axios.get(`http://localhost:3004/api/cart/${username}`).then((response) => {
     if (response.data.status === "success") {
       console.log("success");
       dispatch(userActions.setCart(response.data.data));
     }
   });
   router.push("/Cart");
  }
})
.catch((err)=>{
  console.log(err)
})





 }
 const discountHandler=()=>{
   let code=document.getElementById("discount_code1").value
   if(flag===0 && code==="pharma")
   {
   
   setFlag(1)
  }
  else if(flag===1 && code!=="pharma")
  {
    setFlag(0)
  }
  
 }
    return (
      <div>
        <Header />
        <body class="bg-light">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-10 col-sm-12 mx-auto">
                <div class="row mt-5 gx-3">
                  <h2 class="py-4 font-weight-bold">Cart ({total} items)</h2>
                  <div class="col-md-12 col-lg-8 col-sm-12 mx-auto main_cart mb-lg-0 mb-5 shadow">
                    {cart.map((product) => (
                      <div class="card p-4" id="cartpage">
                        <div class="row">
                          <div class="col-md-5 col-11 mx-auto bg-light d-flex justify-content-center align-items-center shadow product_img">
                            <img
                              src={product.image}
                              class="img-fluid"
                              alt="cart img"
                            />
                          </div>
                          <div class="col-md-7 col-11 mx-auto px-4 mt-2">
                            <div class="row">
                              <div class="col-12 card-title">
                                <h1 class="mb-4 product_name">
                                  {product.product}
                                </h1>
                                <p class="mb-2">Category: {product.category}</p>
                                <p class="mb-2">{product.description}</p>
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-sm-8 d-flex justify-content-between remove_wish">
                                <button
                                  class="btn mb-2 btn-warning"
                                  onClick={() =>
                                    deleteCartItem(product.product, product._id)
                                  }
                                >
                                  <i class="fas fa-trash-alt"></i> REMOVE ITEM
                                </button>
                              </div>
                              <div class="col-sm-6 d-flex justify-content-end price_money">
                                <h3>
                                  Rs.<span id="itemval1">{product.price} </span>
                                </h3>
                              </div>
                            </div>
                          </div>

                          <div class="border-top my-3"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                  {cart.length >= 1 && (
                    <div class="col-md-12 col-lg-4 col-11 mx-auto mt-lg-0 mt-md-5">
                      <div class="right_side p-3 shadow bg-white">
                        <h2 class="product_name mb-5">The Total Amount Of</h2>
                        <div class="price_indiv d-flex justify-content-between">
                          <p>Product amount</p>
                          <p>
                            Rs.<span id="product_total_amt">{totalprice}</span>
                          </p>
                        </div>
                        <div class="price_indiv d-flex justify-content-between">
                          <p>Shipping Charge</p>
                          <p>
                            Rs.<span id="shipping_charge">50.0</span>
                          </p>
                        </div>
                        {flag ? (<div class="price_indiv d-flex justify-content-between">
                          <p>Discount Applied</p>
                          <p>
                            Rs.<span id="shipping_charge">50.0</span>
                          </p>
                        </div>): <div></div>}

                        <hr />
                        <div class="total-amt d-flex justify-content-between font-weight-bold">
                          <p>The total amount of (including VAT)</p>
                          {!flag ? (
                            <p>
                              Rs.
                              <span id="total_cart_amt">{totalprice + 50}</span>
                            </p>
                          ) : (
                            <p>
                              Rs.
                              <span id="total_cart_amt">{totalprice}</span>
                            </p>
                          )}
                        </div>
                        <button
                          class="btn btn-primary text-uppercase"
                          onClick={checkoutHandler}
                        >
                          Checkout
                        </button>
                      </div>
                      <div class="discount_code mt-3 shadow">
                        <div class="card">
                          <div class="card-body">
                            <a
                              class="d-flex justify-content-between"
                              data-toggle="collapse"
                              href="#collapseExample"
                              aria-expanded="false"
                              aria-controls="collapseExample"
                            >
                              Add a discount code (optional)
                              <span>
                                <i class="fas fa-chevron-down pt-1"></i>
                              </span>
                            </a>
                            <input
                              type="text"
                              name=""
                              id="discount_code1"
                              class="form-control font-weight-bold"
                              placeholder="Enter the discount code"
                            />
                            <button
                              class="btn btn-primary btn-sm mt-3"
                              onClick={discountHandler}
                            >
                              Apply
                            </button>
                          </div>
                        </div>
                      </div>

                      <div class="mt-3 shadow p-3 bg-white" id="delivery_date">
                        <div class="pt-4">
                          <h5 class="mb-8">Expected delivery date</h5>
                          <p class="mb-8">
                            October 27th 2021 - October 29th 2021
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </body>
        <Footer />
      </div>
    );
}

export default CartPage;