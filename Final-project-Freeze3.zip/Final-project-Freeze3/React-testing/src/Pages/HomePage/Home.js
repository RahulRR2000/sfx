import React from 'react';
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'
import covid from '../../assets/covid-essentials.jpg'
import './homepage.css'
import { userActions,authActions} from '../../store/reduxStore';
import { useSelector, useDispatch} from 'react-redux'
import axios from 'axios';
import SignIn from '../../Components/SignIn/SignIn'
import Carousel from '../../Components/Carousel/Carousel'
import Beauty from '../../Components/Beauty/Beauty'
import Wellness from '../../Components/Wellness/Wellness'
import Medicines from '../../Components/Medicines/Medicine'
const Home=() =>{
    const username = useSelector((state) => state.userDetails.username);
    const isAuthenticated = useSelector((state) => state.authentication.isAuthenticated)
  /* const orders;
    axios.get("http://localhost:3004/api/Getproducts").then((response)=>{
     
  })
     */
    return (
      <div>
        <Header />

      
        {isAuthenticated && (<div>
          <Carousel/>
          
         <Wellness/>
        <Beauty/>
        <Medicines/>
        </div>)}
        {!isAuthenticated && (<SignIn/>)}
        <Footer />
      </div>
    );
}
export default Home;