import Header from "../../Components/Header/Header"
import Footer from "../../Components/Footer/Footer"
import "./orderPlaced.css"
import { useSelector } from "react-redux"
const OrderPlaced=()=>{
const firstName=useSelector((state)=>state.recepientDetails.firstName)
const lastName=useSelector((state)=>state.recepientDetails.lastName)
const phoneNumber=useSelector((state)=>state.recepientDetails.phoneNumber)
const address=useSelector((state)=>state.recepientDetails.address)
    return (
      <div>
        <Header />
        <div class="container">
          <div class="orderplacedcard">
            <div class="checkmark">
              <i>✓</i>
            </div>

            <h1 class="orderplacedheader">Order Confirmation</h1>
            <p class="orderplacedmessage">
              We received your purchase request;
              <br /> we'll be in touch shortly!
            </p>

            <div>
              <br />
              <hr />
              <ul class="disp">
                <li>Name: {firstName} {lastName}</li>
                <li>Gmail: ria22@gmail.com</li>
                <li>Address: {address}</li>
                <li>Contact: {phoneNumber}</li>
                <li>
                  <strong>Order No:(3245) 256 -673</strong>
                </li>
              </ul>
              <hr />
            </div>
            <div>
              <span>WE ARE SOCIAL,JOIN US</span>
              <br />
              <br />
              <a href="#" class="fa fa-facebook"></a>
              <a href="#" class="fa fa-twitter"></a>
              <a href="#" class="fa fa-google"></a>
              <a href="#" class="fa fa-linkedin"></a>
              <a href="#" class="fa fa-instagram"></a>
            </div>
          </div>
        </div>
        <div class="text-center text-primary">
          <ul class="list-unstyled icn">
            <li>
              <i class="fas fa-map-marker-alt fa-1.5x sa1"></i>
              <p class="text-dark">Chennai , TN 65, TN</p>
            </li>

            <li>
              <i class="fas fa-phone fa-1.5x sa2"></i>
              <p class="text-dark">6576 76576 76576</p>
            </li>

            <li>
              <i class="fas fa-envelope fa-1.5x sa3"></i>
              <p class="text-dark">theproviders98@gmail.com</p>
            </li>
          </ul>
        </div>

        <Footer />
      </div>
    );
}
export default OrderPlaced;