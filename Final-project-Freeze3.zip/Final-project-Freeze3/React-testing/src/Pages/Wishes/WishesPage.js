import { useSelector,useDispatch } from "react-redux";
import img1 from "../../assets/Skincare.jpg";
import { userActions } from "../../store/reduxStore";
import Header from "../../Components/Header/Header";
import Footer from "../../Components/Footer/Footer";
import axios from "axios";
import {useHistory} from "react-router-dom"
const WishesPage = () => {
  let username = useSelector((state) => state.userDetails.username);
  let wishes = useSelector((state) => state.userDetails.wishes);
  let total = wishes.length;
  const router=useHistory();
  const dispatch=useDispatch();
 
  const deleteWishListItem= (product,id) =>{
 let data = {
   username,
   product: product,
 };
 axios
   .delete(`http://localhost:3004/api/deleteWishListItem/${id}`, { data })
   .then((response) => {
     if (response.data.status === "success") {
       console.log("delete success");

       //  dispatch(userActions.setCart(response.data.data.cart));
       axios
         .get(`http://localhost:3004/api/getWishes/${username}`)
         .then((response) => {
           if (response.data.status === "success") {
             console.log("success");
             dispatch(userActions.setWishes(response.data.data));
           }
         });
       router.push("/Wishes");
     }
   })
   .catch((err) => {
     console.log(err);
   });




  }

   const cartHandler = (product) => {
     axios
       .get(`http://localhost:3004/api/Getproduct/${product.product}`)
       .then((response) => {
         if (response.data.status === "success") {
           //dispatch(userActions.setCart(response.data.data));
           let usernameAndProduct = {
             username,
             product: response.data.data,
           };

           axios
             .put("http://localhost:3004/api/getCart", usernameAndProduct)
             .then((response) => {
               if (response.data.status === "success") {
                 console.log("success");
                 console.log("*", response.data.data, "*");
                 deleteWishListItem(product.product,product._id)

                 // dispatch(userActions.setCart(response.data.data));
               }
             });
         }
       });
     console.log();
   };
  return (
    <body class="bg-light">
      <Header />
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-10 col-sm-11 mx-auto">
            <div class="row mt-5 gx-3">
              <h2 class="py-4 font-weight-bold">Wishes ({total} items)</h2>
              <div class="col-md-12 col-lg-8 col-sm-11 mx-auto main_cart mb-lg-0 mb-5 shadow">
                {wishes.map((product) => (
                  <div class="card p-4" id="cartpage">
                    <div class="row">
                      <div class="col-md-5 col-11 mx-auto bg-light d-flex justify-content-center align-items-center shadow product_img">
                        <img
                          src={product.image}
                          class="img-fluid"
                          alt="cart img"
                        />
                      </div>
                      <div class="col-md-7 col-sm-11 mx-auto px-4 mt-2">
                        <div class="row">
                          <div class="col-12 card-title">
                            <h1 class="mb-4 product_name">{product.product}</h1>
                            <p class="mb-2">Category: {product.category}</p>
                            <p class="mb-2">{product.description}</p>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-6 d-flex justify-content-end price_money">
                            <h3>
                              Rs.<span id="itemval1">{product.price} </span>
                            </h3>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-sm-8 d-flex justify-content-between remove_wish">
                            <button
                              class="btn mb-2 btn-warning"
                              onClick={() => cartHandler(product)}
                            >
                              <i class="fas fa-shopping-cart"></i> Add to Cart
                            </button>
                        
                          </div>
                        </div>
                      </div>

                      <div class="border-top my-3"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </body>
  );
};
export default WishesPage;
