import Header from "../../Components/Header/Header";
import Footer from "../../Components/Footer/Footer";
import Beauty from "../../Components/Beauty/Beauty";
const BeautyPage=()=>{
    return(
        <div>
            <Header/>
            <Beauty/>
            <Footer/>
        </div>
    )
}
export default BeautyPage;