import React from 'react'
import SignIn from './Components/SignIn/SignIn'
const App=() =>{
  return (
    <div>
    <SignIn/>
  </div>
    )
}
export default App;