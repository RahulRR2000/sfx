import React from 'react';
import "../../Pages/HomePage/homepage.css";
import { productActions} from '../../store/reduxStore';
import { useSelector, useDispatch} from 'react-redux'
import { productSpecificationActions,reviewsActions } from "../../store/reduxStore";
import { NavLink } from "react-router-dom";
import axios from 'axios';
import  './wellness.css'

const Wellness =() =>{
 
  const username = useSelector((state) => state.userDetails.username);
  
   const products=useSelector((state)=>state.products.products)
   const wellnessProducts=useSelector((state)=>state.products.wellnessProducts)
   let cart=useSelector((state)=>state.userDetails.cart)
   

   const dispatch=useDispatch();
   dispatch(reviewsActions.setShow(false));
     dispatch(reviewsActions.setReviews([]));
   const flag=useSelector((state)=> state.products.flag)
 
let productTitle = useSelector(
  (state) => state.productSpecification.product_title
);
   if(flag===0)
   {
    axios.get("http://localhost:3004/api/Getproducts").then((response)=>{

      if(response.data.status==='success')
      {
        
      try{
      
      dispatch(productActions.setProducts(response.data.data));
       
     dispatch(productActions.setWellnessProducts(products.filter((product) => product.category === "wellness")));
     dispatch(
       productActions.setBeautyProducts(
         products.filter((product) => product.category === "beauty")
       )
     );
     dispatch(
       productActions.setMedicineProducts(
         products.filter((product) => product.category === "Medicine")
       )
     );
      
       }
          catch(err)
       {
         
         console.log(err)
       }
    
   dispatch(productActions.setFlag());
  
      }
     
  })
   }
   const viewHandler=(product)=>{
axios.get(`http://localhost:3004/api/Getproduct/${product}`)
.then((response)=>{
 if(response.data.status==='success')
 {
 dispatch(
  productSpecificationActions.setProduct_title(response.data.data.product));
  dispatch( 
  productSpecificationActions.setProduct_category(response.data.data.category));
  dispatch(
  productSpecificationActions.setProduct_price(response.data.data.price));
  dispatch(
    productSpecificationActions.setProduct_description(response.data.data.description));
 dispatch(productSpecificationActions.setProduct_image(response.data.data.image))
  }
 else{
    dispatch(
      productSpecificationActions.setProduct_title('none')
    );
 } 
});
   }
const cartHandler = (product)=>{

   axios.get(`http://localhost:3004/api/Getproduct/${product}`)
   .then((response)=>{
     if(response.data.status==='success')
    {
      //dispatch(userActions.setCart(response.data.data));
      let usernameAndProduct={
          username,
          product: response.data.data
      }
    
    
      axios.put("http://localhost:3004/api/getCart",usernameAndProduct)
      .then((response)=>{
        if(response.data.status==="success")
        {
          
        console.log("success");
        console.log('*',response.data.data,'*')
      // dispatch(userActions.setCart(response.data.data));
        }
      })
    }})  
    console.log()
  
  }




  const wishListHandler = (product) => {
    axios
      .get(`http://localhost:3004/api/Getproduct/${product}`)
      .then((response) => {
        if (response.data.status === "success") {
          // dispatch(userActions.setCart(response.data.data));
          let usernameAndProduct = {
            username,
            product: response.data.data,
          };

          axios
            .put("http://localhost:3004/api/addWishes", usernameAndProduct)
            .then((response) => {
              if (response.data.status === "success") {
                console.log("success");
              }
            });
        }
        console.log();
      })
      .catch((err) => {
        console.log(err);
      });
  };

   

    return (
      <div>
        <div class="row">
          <h4 class="heading">Shop by Wellness</h4>
          {wellnessProducts.map((product) => (
            <div class="card  col-md-2 col-sm-5">
              <div class="zoom">
                <img src={product.image} class="card-img-top" alt="..." />
              </div>
              <div class="card-body">
                <h5 class="card-title">{product.product}</h5>
                <h6 class="text-muted card-title">Price: {product.price}</h6>
                <p class="card-text">
                  <small class="text-muted">4 left in stock</small>
                </p>
                <div class="">
                  <button
                    className="btn btn-warning view"
                    onClick={() => viewHandler(product.product)}
                  >
                    <NavLink to="/Specifications" style={{ color: "black" }}>
                      <i class="fas fa-info-circle"></i>
                    </NavLink>
                  </button>
                  <button
                    className="btn btn-warning view"
                    onClick={() => cartHandler(product.product)}
                  >
                    Add to <i class="fas fa-shopping-cart"></i>
                  </button>
                  <button
                    className="btn btn-warning view"
                    onClick={() => wishListHandler(product.product)}
                  >
                    Add to <i class="fa fa-heart" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
export default Wellness;
