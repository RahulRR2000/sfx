const mongoose = require("mongoose");
const recepientSchema = new mongoose.Schema({
  firstName: {
    type: String,
    
  },
  lastName: {
    type: String,
  },
  address: {
      type: String,
  }
});

const Recepient = mongoose.model("Recepient", recepientSchema);
module.exports = Recepient;
