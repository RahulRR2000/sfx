const express = require("express");
const logger = require("morgan");
const cors = require("cors");
const mongoose=require("mongoose"),Schema=mongoose.Schema;
const { error } = require("console");
//const users = JSON.parse(fs.readFileSync(`${__dirname}/data/users.json`));
const User= require("./modals/User")
const Product=require("./modals/Product")
const Recepient=require("./modals/Recepient")
const Reviews=require("./modals/Reviews");
const Admin = require("./modals/Admin");
const app = express();
mongoose
  .connect("mongodb://localhost:27017/trials3", {
  
  })
  .then((res) => {
    console.log("Db connection Successful!");
  })
  .catch((err) => {
    console.log(err);
  });
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("static"));

app.get("/api/Users", async (req, res) =>{
  
 
  //console.log("Users : ", JSON.stringify(users));
  try{
  const users = await User.find().populate('cart').populate('orders');
  res.send({
    status:'success',
    data: users
  });
  }
  catch(err) {

  }
});
app.post("/api/Reviews",async(req,res)=>
{
  try{

    const addedReview= await Reviews.create(req.body);
    console.log(addedReview)
    res.send({
      status: 'success',
      data: addedReview
    })
  }
  catch(err)
  {
  console.log(err)
  res.send({
    status: 'fail',
   data: 'none'
  })
  }
})

app.get("/api/Reviews/:product",async(req,res)=>{
  try{

    const reviews=await Reviews.find({product: req.params.product});
    console.log(req.params.product)
    if(reviews!==null)
    {
      console.log(reviews)
    res.send({
      status: 'success',
      data: reviews
    })
  }
    else
    {
      res.send({
        status: 'success',
        data: []
      })
    }
  }
  catch(err)
  {
    
    res.send({
      status: 'fail',
      data: 'none'
    })
  }
})
app.post("/api/Recepient",async(req,res)=>{
  try{
  const recepient=await Recepient.create(req.body)
  if(recepient!==null)
  {
    res.send({
      status: 'success',
      data: recepient
    })
  }
  else
  {
    res.send({
      status: 'fail',
      data: 'none'
    })
  }
}
catch(err)
{
  console.log(err);
}
})
app.get("/api/Recepient/:firstName/:lastName",async(req,res)=>{
  try{
  const recepient=await Recepient.find({firstName: req.params.firstName,lastName: req.params.lastName})
  if(recepient!==null)
  {
    res.send({
      status: 'success',
      data: recepient
    })
  }
  else{
    res.send({
      status: 'fail',
      data: 'none'
    })
  }
}
catch(err)
{
  console.log(err)
}
})
app.get("/api/getOrders/:username", async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username }).populate('orders');
    console.log(user.orders);
    if (user !== null)
      res.send({
        status: "success",
        data: user.orders,
      });
    else
      res.send({
        status: "fail",
      });
  } catch (err) {
    console.log(err);
  }
});

app.post("/api/Login", async (req,res) => {
  try{
    //const newUser=await User.create({username:req.body.username,password:req.body.password})
  const testUser = await User.findOne({username : req.body.username, password: req.body.password});
console.log(testUser);  
if(testUser===null)
throw error;
//users.push(testUser);

  res.send({
    status:'success',
    data:testUser
  });
}
catch(err){
  console.log(err);
  res.send({
    status:'fail',
    data:'none'
  })
};
})
app.get("/api/adminLogin/:username/:password",async(req,res)=>{
  try{
    const admin=await Admin.findOne({username: req.params.username,password: req.params.password});
    if(admin===null)
    {
      throw error
    }
    res.send({
      status: 'success',
      data: admin
    })
  }
  catch(err)
  {
    console.log(err);
    res.send({
      status: 'fail',
      data: 'none'
    })
  }
})
app.post("/api/adminSignUp",async(req,res)=>{
  try{
    const admin=await Admin.create(req.body)
    if(admin!==null)
    {
    console.log(admin)
    res.send({
      status: 'success',
      data: admin
    })
  }
}
  catch(err)
  {
    console.log(err)
    res.send({
      status: 'fail',
      data: 'none'
    })
  }
})

app.post("/api/SignUp",async(req,res) => {
  try{
    
    const newUser=await User.create(req.body)

    if(newUser!==null)
    res.send({
      status: 'success',
      data: newUser
    })
  }
  catch(err){
    console.log(err);
    res.send({
      status:'fail',
      data:'none'
    })
  }
})
app.post("/api/Addproducts",async(req,res)=>{
  try{
    const newProduct=await Product.create(req.body);
    res.send({
      status:'success',
      data: newProduct
    }) 
  }
  catch(err){
    res.send({
      status:'fail',
      data:'none'
    })

  }
})

app.get("/api/Getproducts",async(req,res)=>{
  try{
    const products=await Product.find({});

    res.send({
      status: 'success',
      data: products 
    })
  }
  catch(err){
    cosnole.log(err)
    res.send({
      status: 'fail',
      data: 'none'
    })
  }
})
app.put("/api/editProduct/:productTitle",async(req,res)=>{
  try{
  const product=await Product.findOneAndReplace({product: req.params.productTitle},req.body)
 if(product!==null)
 {
 res.send({
   status: 'success',
   data: product
 })
 }
 else{
   res.send({
     status: 'fail',
     data: 'none'
   })
 }  
}
catch(err)
{
  console.log(err)
}
})
app.delete("/api/deleteProduct/:product",async(req,res)=>{
  try{
    Product.findOne({product: req.params.product}, function (error, prod){
        console.log("This object will get deleted " + prod);
        prod.remove();
  res.send({
    status: 'success',
    data: prod
  })
    });
  }
  catch(err)
  {
    console.log(err)
  }
})
app.get("/api/Getproduct/:product",async(req,res) =>{
  try{
    const product=await Product.findOne({product: req.params.product})
 //   console.log(product)
   
    if(product!==null)
    res.send({
      status: 'success',
      data: product
    })
    else
    {
res.send({
  status: "fail",
  data: "none",
});
    }

  }
  catch(err){
    console.log(err)
    
  }
})
app.get("/api/cart/:username",async(req,res)=>{
  try{
    const user=await User.findOne({username: req.params.username}).populate('cart');
  //  console.log(user.cart)
    if(user!==null)
    res.send({
      status: 'success',
      data: user.cart
    })
    else
res.send({
  status: "fail",
  data: user.cart,
});
  }
  catch(err)
  {
console.log(err)
  }
})
app.put("/api/deleteCart",async(req,res)=>{
  try{
    const user=await User.findOneAndUpdate({username: req.body.username},{cart: req.body.cart }).populate('cart');
 
   res.send({
   status: 'success',
   data: user
 })
  }
  catch(err)
  {
     res.send({
       status: 'fail'
     })
  }
})
app.delete("/api/deleteCartItem/:id",async(req,res)=>{
  try{
   console.log(req.body.username,req.body.product)
    const item=await User.findOneAndUpdate({username: req.body.username}, {$pull: {"cart" : { _id: req.params.id}}}).populate('cart').populate('orders')
    for(i=0;i<item.cart.length;i++)
    {
      console.log(item.cart[i].product);
      if(item.cart[i].product===req.body.product)
      {
        console.log('entered')
        item.cart.splice(i,1)
      }
    }
    const item2=await User.findOneAndUpdate({username: req.body.username},{cart: item.cart})
    if(item2!==null)
    {
    res.send({
      status: 'success',
      data: item2
    })
  }

    else
    {
res.send({
  status: "fail",
});
    }

  }
  catch(err)
  {
   res.send({
     status: 'fail'
   }) 
  }

})
app.put("/api/getCart",async(req,res)=>{
  try{
  
  const user=await User.findOneAndUpdate({username: req.body.username},{$push: {cart: req.body.product}}).populate('cart');

 console.log(user);
 
    if(user!==null)
   {
    res.send({
      status: 'success',
      data: user.cart
    })
  }
  else
  {
    res.send({
      status: "fail",
    });
  }
  }
  catch(err)
  {
console.log(err)
  }
})
app.put("/api/addWishes",async(req,res)=>{
   try{
  const user=await User.findOneAndUpdate({username: req.body.username},{$push: {wishes: req.body.product}}).populate('wishes');
if(user!==null)
   {
    res.send({
      status: 'success',
      data: user.wishes
    })
  }
  else
  {
    res.send({
      status: "fail",
    });
  }
  }
  catch(err)
  {
console.log(err)
  }
})
app.put("/api/addOrders",async(req,res) => {
  try{
  console.log(req.body.username,req.body.orders)
  
  const user=await User.findOneAndUpdate({username: req.body.username},{$push: {orders: req.body._id}}).populate('orders');
console.log(user.orders)
if(user!==null)
   {
    res.send({
      status: 'success',
      data: user.orders
    })
  }
  else
  {
    res.send({
      status: "fail",
    });
  }
  }
  catch(err)
  {
    
res.send({
  status: 'fail'
})
console.log(err)
  }
}
)
app.get("/api/getWishes/:username",async(req,res)=>{
  try {
    const user = await User.findOne({ username: req.params.username }).populate(
      "wishes"
    );
    console.log(user.wishes);
    if (user !== null)
      res.send({
        status: "success",
        data: user.wishes,
      });
    else
      res.send({
        status: "fail",
      });
  } catch (err) {
    console.log(err);
  }
})




app.delete("/api/deleteWishListItem/:id",async(req,res)=>{
  try {
    console.log(req.body.username, req.body.product);
    const item = await User.findOneAndUpdate(
      { username: req.body.username },
      { $pull: { wishes: { _id: req.params.id } } }
    ).populate("wishes");
    for (i = 0; i < item.wishes.length; i++) {
      console.log(item.wishes[i].product);
      if (item.wishes[i].product === req.body.product) {
        console.log("entered");
        item.wishes.splice(i, 1);
      }
    }
    const item2 = await User.findOneAndUpdate(
      { username: req.body.username },
      { wishes: item.wishes }
    );
    if (item2 !== null) {
      res.send({
        status: "success",
        data: item2,
      });
    } else {
      res.send({
        status: "fail",
      });
    }
  } catch (err) {
    res.send({
      status: "fail",
    });
  }

})


//start your server on port 3001
app.listen(3004, () => {
  console.log("Server Listening on port 3004");
});
