const mongoose=require("mongoose")
const productSchema = new mongoose.Schema({
  product: {
    type: String,
    unique: true,
  },
  category: {
    type: String,
  },
  price: {
    type: Number,
  },
  description: {
    type: String,
  },
  manufacturedBy: {
    type: String,
  },
  image: {
    type: String,
  },
});






const Product=mongoose.model('Product',productSchema);
module.exports= Product