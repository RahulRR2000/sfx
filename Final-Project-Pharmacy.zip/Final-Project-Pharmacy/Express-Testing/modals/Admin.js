const mongoose = require("mongoose"),
  Schema = mongoose.Schema;
const adminSchema = new mongoose.Schema({
  username: {
    type: String,
  },
  password: {
    type: String,
  },
});

const Admin = mongoose.model("Admin", adminSchema);
module.exports = Admin;
