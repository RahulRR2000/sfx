
const mongoose = require("mongoose"),
  Schema = mongoose.Schema;
const usersSchema = new mongoose.Schema({
  username: {
    type: String,
  },
  password: {
    type: String,
    
  },
  phoneNumber: {
    type: Number,
    unique: true,
  },
  cart: [{ type: Schema.Types.ObjectId, ref: "Product" }],
  orders: [{ type: Schema.Types.ObjectId, ref: "Product" }],
  wishes: [{ type: Schema.Types.ObjectId, ref: "Product" }],
});

const User = mongoose.model("User", usersSchema);
module.exports= User;
