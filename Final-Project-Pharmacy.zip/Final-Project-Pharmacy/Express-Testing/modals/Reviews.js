const mongoose = require("mongoose");
const reviewsSchema = new mongoose.Schema({
  product: {
    type: String,
  },
  username: {
      type: String,
  },
  reviews: {
    type: String,
    required: true,

},

  
});

const Reviews = mongoose.model("Reviews", reviewsSchema);
module.exports = Reviews;
