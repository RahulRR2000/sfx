import axios from "axios"
import { useSelector,useDispatch } from "react-redux"
import {useHistory} from 'react-router-dom'
import "./paymentPage.css"
import {useState} from "react"
import Header from "../../Components/Header/Header"
import Footer from "../../Components/Footer/Footer"
import CardPayment from "./CardPayment"
import { cardValidationActions,recepientDetailsActions } from "../../store/reduxStore"
const PaymentPage=()=>
{
const [cardPaymentClicked,setCardPaymentClicked]=useState(false)
const totalPrice=useSelector((state)=>state.totalPrice.totalPrice)
const username=useSelector((state)=>state.userDetails.username)
const cart=useSelector((state) => state.userDetails.cart)
const valid=useSelector((state)=>state.cardValidation.valid);
const router=useHistory();
const dispatch=useDispatch();
const clearCart=()=>
{
    let user={
        username,
        cart: []
    }
    axios.put("http://localhost:3004/api/deleteCart",user)
    .then((response)=>{
    if(response.data.status==='success')
    {
        console.log("cleared cart");
    }
    })
    .catch((err)=>{
        console.log(err)
    });
}
const addOrders=()=>{
     for(let i=0;i<cart.length;i++)
   {
       let user={
           username,
           _id: cart[i]._id
       }

       axios.put("http://localhost:3004/api/addOrders",user)
       .then((response)=>{
           if(response.data.status==='success')
           {
               
               console.log("added to cart")
              // counter++;           
             }
       })
       .catch((err)=>{
           console.log(err)
       });
   }
}

const cardPaymentHandler=()=>{
addOrders();
clearCart();

dispatch(cardValidationActions.setValid())

router.push("/OrderPlaced")
}

const cardPageHandler=()=>{
  
  dispatch(
    recepientDetailsActions.setFirstName(
      document.getElementById("firstName").value
    )
  );
  dispatch(
    recepientDetailsActions.setLastName(
      document.getElementById("lastName").value
    )
  );
  dispatch(
    recepientDetailsActions.setAddress(document.getElementById("address").value)
  );
  dispatch(
    recepientDetailsActions.setPhoneNumber(
      document.getElementById("phoneNumber").value
    )
  );
setCardPaymentClicked(true);


}


if (valid) cardPaymentHandler();
    return (
      <div>
        <Header />
        {cardPaymentClicked && <CardPayment />}
        {!cardPaymentClicked && (
          <div class="body">
            <div class="cont">
              <div class="container">
                <section class="mb-4">
                  <form class="Contactform" onSubmit={cardPageHandler}>
                    <div class="row res">
                      <div class="col-md-9 col-sm-9 mb-md-0 mb-5">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="md-form mb-0">
                              <input
                                type="text"
                                name="name"
                                id="firstName"
                                class="form-control"
                                required
                              />
                              <label for="name">First name</label>
                            </div>
                          </div>

                          <div class="col-md-6">
                            <div class="md-form mb-0">
                              <input
                                type="text"
                                name="name"
                                id="lastName"
                                class="form-control"
                                required
                              />
                              <label for="name">Last Name</label>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-md-12">
                            <div class="md-form mb-0">
                              <input
                                type="tel"
                                name="phone"
                                id="phoneNumber"
                                class="form-control"
                                pattern="[0-9]{10}"
                                required
                              />
                              <label for="phoneNumber">Alternate No</label>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-md-12">
                            <div class="md-form">
                              <textarea
                                type="text"
                                name="address"
                                rows="3"
                                id="address"
                                class="form-control md-textarea"
                                required
                              ></textarea>
                              <label for="address">Your Address</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="text-center text-md-lefts">
                      <button class="btn btn-primary but2" type="submit">
                        Card Payment
                      </button>
                    </div>
                  </form>
                  <div class="text-center text-md-lefts"></div>

                  <div class="text-center text-primary">
                    <ul class="list-unstyled icn">
                      <li>
                        <i class="fas fa-map-marker-alt fa-1.5x sa1"></i>
                        <p class="text-dark">Chennai , TN 65, TN</p>
                      </li>

                      <li>
                        <i class="fas fa-phone fa-1.5x sa2"></i>
                        <p class="text-dark">6576 76576 76576</p>
                      </li>

                      <li>
                        <i class="fas fa-envelope fa-1.5x sa3"></i>
                        <p class="text-dark">theproviders98@gmail.com</p>
                      </li>
                    </ul>
                  </div>
                </section>
              </div>
            </div>
          </div>
        )}
        <Footer />
      </div>
    );
}
export default PaymentPage;