import { useSelector,useDispatch } from "react-redux"
import { cardValidationActions,recepientDetailsActions } from "../../store/reduxStore";
import {useHistory} from "react-router-dom"
import "./cardPayment.css"
const CardPayment=()=>{
const router=useHistory();
const dispatch=useDispatch()
const cardDetailsHandler=(event)=>{

dispatch(cardValidationActions.setValid());


//router.push("/OrderPlaced")
}

return (
  <div>
    <div class="wrapper">
      <h2 class="h2">Payment Form</h2>
      <form onSubmit={cardDetailsHandler}>
        <h6>Account</h6>
        <div class="input-group">
          <div class="input-box">
            <input
              id="firstname"
              type="text"
              placeholder="Name on Card"
              required
              class="name"
            />
            <i class="fa fa-user icon"></i>
          </div>
        </div>

        <div class="input-group">
          <div class="input-box">
            <h6>Payment Details</h6>
            <input
              type="radio"
              id="bc1"
              name="pay"
              checked
              class="radio"
              required
            />
            <label for="bc1">
              <span>
                <i class="fa fa-cc-visa"></i>Credit Cards
              </span>
            </label>
            <input
              type="radio"
              id="bc2"
              name="pay"
              checked
              class="radio"
              required
            />
            <label for="bc2">
              <span>
                <i class="fa fa-cc-paypal"></i>Paypal
              </span>
            </label>
          </div>
        </div>
        <div class="input-group">
          <div class="input-box">
            <input
              type="tel"
              placeholder="Card Number"
              pattern="^4[0-9]{12}(?:[0-9]{3})?$"
              class="name"
              required
            />
            <i class="fa fa-credit-card icon"></i>
          </div>
        </div>
        <div class="input-group">
          <div class="input-box">
            <input
              type="tel"
              placeholder="Card CVC"
              pattern="^[0-9]{3}$"
              class="name"
              required
            />
            <i class="fa fa-user icon"></i>
          </div>
          <div class="input-box">
            <select>
              <option>01 june</option>
              <option>02 june</option>
              <option>03 june</option>
            </select>
            <select>
              <option>2021</option>
              <option>2022</option>
              <option>2023</option>
            </select>
          </div>
        </div>
        <div class="input-group">
          <div class="input-box">
            <button class="button" type="Submit">
              Pay Now
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
);
    }


export default CardPayment;