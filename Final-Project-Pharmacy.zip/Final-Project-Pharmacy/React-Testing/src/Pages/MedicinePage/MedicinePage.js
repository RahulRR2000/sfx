import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'
import Medicine from '../../Components/Medicines/Medicine'

const MedicinePage=()=>{
    return(
        <div>
        <Header/>
        <Medicine/>
        <Footer/>
    </div>
    )
}
export default MedicinePage;