import "../Footer/footer.css"
const Footer = () => {
  return (
    <div class="footer">
      <footer>
        <div className="text-center text-dark p-3 bg-warning">
          © 2020 Copyright: &nbsp;
          <span className="text-dark" href="https://mdbootstrap.com/">
            Pharma & Ltd
          </span>
        </div>
      </footer>
    </div>
  );
};
export default Footer;
