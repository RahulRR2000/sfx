import axios from 'axios';
import React from 'react'
import { useSelector } from 'react-redux';
import { productActions, userActions } from "../../store/reduxStore";

const Cart = ()=>{

 let cart = useSelector((state) => state.userDetails.cart);
 console.log(cart)
 const username=useSelector((state)=>state.userDetails.username)
 const deleteCartItem=(product)=>{
axios.put(`http://localhost:3004/api/deleteCartItem/${product}`,username)
.then((response)=>{
  if(response.data.status==='success')
  {
    console.log("delete success")
  }
})
.catch((err)=>{
  console.log(err)
})

 }
return (
  <div>
    <table id="table-data" className="table table-dark table-hover">
      <tbody>
        <tr>
          <th>Product Name</th>
          <th>Category</th>
          <th colSpan="2">Product Name</th>
          <th>Description</th>
        </tr>
        
        {cart.map((product) => (
          <tr key={product.product}>
            <th scope="row">{product.product}</th>
            <th scope="row">{product.category}</th>
            <td colSpan="2">{product.price}</td>
            <td colSpan="2">{product.description}</td>
            <td colSpan="2"><button clsss="btn btn-warning" onClick={()=>deleteCartItem(product.product)}>delete</button></td>

          </tr>
        ))}
      </tbody>
    </table>
  </div>
)}
export default Cart;