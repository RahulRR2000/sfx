
import Skincare from '../../assets/Skincare.jpg'
import '../../Pages/HomePage/homepage.css'
import {NavLink} from 'react-router-dom'
//import { userActions, productActions } from '../../store/reduxStore';
import { useSelector, useDispatch} from 'react-redux'
import { productSpecificationActions, userActions,reviewsActions } from "../../store/reduxStore";
import HairOil from "../../assets/Hair oil.jpg" 
import HimalayaUnderEyeCream from "../../assets/Himalaya Under Eye Cream.jpg"; 
import AromaShowerGel from "../../assets/Aroma Shower Gel.jpg"; 
import KlairRichMoistSoothingCream from "../../assets/Klair Rich Moist Smoothing Cream.jpg"; 

import axios from 'axios';
const Beauty=() =>{
    const username = useSelector((state) => state.userDetails.username);
    const beautyProducts=useSelector((state) => state.products.beautyProducts);
    const dispatch=useDispatch();
    dispatch(reviewsActions.setShow(false));
    dispatch(reviewsActions.setReviews([]))
 const images2 = [
   { title: "Hair Oil", source: HairOil},
   { title: "Aroma Shower Gel", source: AromaShowerGel},
   { title: "Klairs Rich Moist Soothing Cream 60 ml", source: KlairRichMoistSoothingCream},
   { title: "Under Eye Cream", source: HimalayaUnderEyeCream}
 ];
   // const quantity=useSelector((state) => state.products.quantity)
   /*const orders;
    axios.get("http://localhost:3004/api/Getproducts").then((response)=>{
     
  })*/
  const viewHandler = (product) => {
    axios
      .get(`http://localhost:3004/api/Getproduct/${product}`)
      .then((response) => {
        if (response.data.status === "success") {
          dispatch(
            productSpecificationActions.setProduct_title(
              response.data.data.product
            )
          );
          dispatch(
            productSpecificationActions.setProduct_category(
              response.data.data.category
            )
          );
          dispatch(
            productSpecificationActions.setProduct_price(
              response.data.data.price
            )
          );
          dispatch(
            productSpecificationActions.setProduct_description(
              response.data.data.description
            )
          );
          dispatch(
            productSpecificationActions.setProduct_image(
              response.data.data.image
            )
          );
          dispatch(productSpecificationActions.setProduct_manufacturedBy(response.data.data.manufacturedBy))
        } else {
          dispatch(productSpecificationActions.setProduct_title("none"));
        }
      });
  };
  const cartHandler = (product) => {
    axios
      .get(`http://localhost:3004/api/Getproduct/${product}`)
      .then((response) => {
        if (response.data.status === "success") {
         // dispatch(userActions.setCart(response.data.data));
let usernameAndProduct = {
  username,
  product: response.data.data,
};

axios
  .put("http://localhost:3004/api/getCart", usernameAndProduct)
  .then((response) => {
    if (response.data.status === "success") {
      console.log("success");
      console.log("*", response.data.data, "*");
      // dispatch(userActions.setCart(response.data.data));
    }
  });


        }
      //  console.log();
      })
      .catch((err) => {
        console.log(err);
      });


  };
  const wishListHandler = (product) => {
    axios
      .get(`http://localhost:3004/api/Getproduct/${product}`)
      .then((response) => {
        if (response.data.status === "success") {
          // dispatch(userActions.setCart(response.data.data));
          let usernameAndProduct = {
            username,
            product: response.data.data,
          };

          axios
            .put("http://localhost:3004/api/addWishes", usernameAndProduct)
            .then((response) => {
              if (response.data.status === "success") {
                console.log("success");
              }
            });
        }
        console.log();
      })
      .catch((err) => {
        console.log(err);
      });
  };

   
     
    return (
      <div id="outer-div">
        <div class="row" id="beauty-row">
          <h4 class="heading">Shop by Beauty Products</h4>
          {beautyProducts.map((product) => (
            <div id="beauty-card" class="card  col-md-2 col-11">
              <div class="zoom">
                <img
                  id="card-image"
                  src={
                    images2.filter((image) => image.title === product.product)[0]
                      .source
                  }
                  class="card-img-top"
                  alt="..."
                />
              </div>
              <div class="card-body">
                <h5 class="card-title">{product.product}</h5>
                <h6 class="text-muted card-title">Price: {product.price}</h6>

                <p class="card-text">
                  <small class="text-muted">4 left in stock</small>
                </p>
                <div class="text-center">
                  <button
                    className="btn btn-warning view"
                    onClick={() => viewHandler(product.product)}
                  >
                    <NavLink to="/Specifications" style={{ color: "black" }}>
                      <i class="fas fa-info-circle"></i>
                    </NavLink>
                  </button>
                  <button
                    className="btn btn-warning view"
                    onClick={() => cartHandler(product.product)}
                  >
                    Add to <i class="fas fa-shopping-cart"></i>
                  </button>
                  <button
                    className="btn btn-warning view"
                    onClick={() => wishListHandler(product.product)}
                  >
                    Add to <i class="fa fa-heart" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
}
export default Beauty;