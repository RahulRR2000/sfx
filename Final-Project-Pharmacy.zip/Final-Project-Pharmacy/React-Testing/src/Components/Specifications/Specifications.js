import axios from 'axios'
import React from 'react'
import covid from '../../assets/covid-essentials.jpg'
import { counterActions, productSpecificationActions,reviewsActions} from '../../store/reduxStore';
import { useSelector, useDispatch} from 'react-redux'
import Header from "../Header/Header"
import Footer from "../Footer/Footer"
import "./specifications.css"

const Specifications= ()=>{

const dispatch=useDispatch()
let username=useSelector((state)=>state.userDetails.username)
let productTitle = useSelector((state) => state.productSpecification.product_title);
let productPrice = useSelector(
  (state) => state.productSpecification.product_price
);
let productDescription = useSelector(
  (state) => state.productSpecification.product_description
);
let productCategory = useSelector(
  (state) => state.productSpecification.product_category
);
let image=useSelector((state)=>state.productSpecification.product_image)
//console.log(productPrice,productCategory)
let product_manufacturedBy=useSelector((state)=>state.productSpecification.product_manufacturedBy)

let reviews=useSelector((state)=>state.reviews.reviews)
let show=useSelector((state)=>state.reviews.show)
const reviewHandler=(product)=>{
   console.log(product);
  axios.get(`http://localhost:3004/api/Reviews/${product}`)
  .then((response)=>{
    if(response.data.status==='success')
    {
      dispatch(reviewsActions.setReviews(response.data.data))
    }
    
  })
  .catch((err)=>{
   console.log(err)
  })
}
const writeReviewHandler=(product)=>{
  let reviews=document.getElementById("review-textarea").value;
  reviews=reviews.trim()
  let reviewBody={
   product,
   username,
   reviews
  }
  axios.post("http://localhost:3004/api/Reviews",reviewBody);
  showReviewHandler(product)
}
const showReviewHandler=(product)=>{
 
dispatch(reviewsActions.setShow(!show))
reviewHandler(product)
}

const cartHandler = (product) => {
  axios
    .get(`http://localhost:3004/api/Getproduct/${product}`)
    .then((response) => {
      if (response.data.status === "success") {
        //dispatch(userActions.setCart(response.data.data));
        let usernameAndProduct = {
          username,
          product: response.data.data,
        };

        axios
          .put("http://localhost:3004/api/getCart", usernameAndProduct)
          .then((response) => {
            if (response.data.status === "success") {
              console.log("success");
              console.log("*", response.data.data, "*");
              // dispatch(userActions.setCart(response.data.data));
            }
          });
      }
    });
  console.log();
};

return (
  <div>
    <Header />
    <div class="row mainspecification">
      <div class="col-md-6 my-5 sp-left">
        <img src={image} class="card-img-top" alt="..." />
      </div>
      <div class="col-md-4  my-5 sp-right">
        <div class="row">
          <div class="col-md-10">
            <div class="col-md-12">
              <h5 class="productDescription">{productDescription}</h5>
              <small>
                <span class="fungal">Fungal </span>
                <span class="rx">Rx required </span>
                <span class="specification-category">{productCategory}</span>
              </small>
              <p clas="product-title">{productTitle}</p>
            </div>
          </div>
        </div>
        <hr></hr>
        <div class="row">
          <h4 class="price">
            Best price* Rs.<em>{productPrice}</em>
          </h4>
          <div class="text-muted">
            <small>(Inclusive of all taxes)</small>
            <br></br>
            <small>
              * Get the Best price on the product on Orders above Rs.999/-
            </small>
            <br></br>
            <small>Mkt:{product_manufacturedBy}</small>
            <br></br>
            <small>Country of Origin: India</small>
            <br></br>
            <small>
              Delivery charges if applicable will applied at checkout
            </small>
          </div>
          <button
            class="btn addToCart"
            onClick={() => cartHandler(productTitle)}
          >
            ADD TO CART
          </button>
        </div>
        <hr></hr>
      </div>
      <div></div>
    </div>
    <div>
      <button
        class="btn btn-light review-button"
        onClick={() => showReviewHandler(productTitle)}
      >
        show more...
      </button>
      {show &&
        reviews.map((review) => (
          <div class="container" key={review._id}>
            <h6>{review.username}</h6>
            <p>{review.reviews}</p>
            <hr/>
          </div>
        ))}
        {show &&
      (<div><button
        class="btn btn-light review-button"
        onClick={() => writeReviewHandler(productTitle)}
      >
        Write Review</button><div class="input-group">
  <div class="input-group-prepend">
    <span class="input-group-text p-4">{username}</span>
  </div>
  <textarea class="form-control" id="review-textarea" aria-label="With textarea"></textarea>
</div></div>)}
    </div>
    <div class="row aboutProduct">
      <div class="aboutProduct-leftside col">
        <p>Product Name</p>
        
        <p>Product origin</p>
     
        <p>Product Weight</p>
        
        <p>Product Manufacturer</p>
      </div>
      <div class="aboutProduct-rightside col">
        <p>{productTitle}</p>
      
        <p>India</p>
        
        <p>200g</p>
        
        <p>{product_manufacturedBy}20</p>
      </div>
    </div>
    <Footer />
  </div>
);
}
export default Specifications;