import {NavLink} from "react-router-dom"
import axios from "axios"
import { useSelector,useDispatch } from "react-redux";
import {useHistory} from "react-router-dom"

import { productActions,productSpecificationActions } from "../../store/reduxStore";
const AdminEditPage=()=>{
    const dispatch=useDispatch()
let productTitle = useSelector((state) => state.productSpecification.product_title);
let productPrice = useSelector(
  (state) => state.productSpecification.product_price
);
let productDescription = useSelector(
  (state) => state.productSpecification.product_description
);
let productCategory = useSelector(
  (state) => state.productSpecification.product_category
);
let image=useSelector((state)=>state.productSpecification.product_image)
//console.log(productPrice,productCategory)

let product_manufacturedBy=useSelector((state)=>state.productSpecification.product_manufacturedBy)
const router=useHistory()
    const formHandler=(productName)=>{
      
              let form = document.getElementById("product-form").elements;
              let product = form["title"].value;
              let category = form["category"].value;
              let price = form["price"].value;
              let description = form["description"].value;
              let manufacturedBy = form["manufacturer"].value;
              let image = form["image-url"].value;
              if(product===''||category===''||price===''||description===''||manufacturedBy===''||image==='')
              {
               document.getElementById("error-field").className="invalid-credentials";
               return;
              }
              else
              {
                 document.getElementById("error-field").className = "valid-credentials";
              }
              let productDetails = {
                product,
                category,
                price,
                description,
                manufacturedBy,
                image,
              };
              axios.put(`http://localhost:3004/api/editProduct/${productName}`,productDetails)
              .then((response)=>{
                if(response.data.status==='success')
                {
                axios
                  .get("http://localhost:3004/api/Getproducts")
                  .then((response) => {
                    if (response.data.status === "success") {
                      try {
                        dispatch(
                          productActions.setProducts(response.data.data)
                        );
                      } catch (err) {
                        console.log(err);
                      }
                    
                   
                   } });
                
                }
                router.push("/AdminHomePage") 
              })
    }
    const titleHandler=(e)=>{
      dispatch(productSpecificationActions.setProduct_title(e.target.value))
    }
    const categoryHandler=(e)=>{
dispatch(productSpecificationActions.setProduct_category(e.target.value));
    }
    const priceHandler=(e)=>{
     dispatch(productSpecificationActions.setProduct_price(e.target.value));
    }
    const descriptionHandler=(e)=>{
  dispatch(productSpecificationActions.setProduct_description(e.target.value));
    }
    const manufacturedByHandler=(e)=>{
     dispatch(productSpecificationActions.setProduct_manufacturedBy(e.target.value));
    }
    const imageHandler=(e)=>{
   dispatch(productSpecificationActions.setProduct_image(e.target.value));
    }
  return (
    <div>
      <NavLink to="/AdminHomePage">
        <button class="btn btn-warning">Go to Home page</button>
      </NavLink>
      <form id="product-form">
        <p id="error-field" className="valid-credentials">*All the fields are mandatory!!</p>
        <label class="admin-label">Product Title</label>
        <input
          type="text"
          class="form-control"
          value={productTitle}
          id="title"
          required
        />
        <label class="admin-label">Product Category</label>
        <input
          type="text"
          class="form-control"
          value={productCategory}
          id="category"
          onChange={categoryHandler}
          required
        />
        <label class="admin-label">Product Price</label>
        <input
          type="number"
          class="form-control"
          value={productPrice}
          id="price"
          onChange={priceHandler}
          required
        />
        <label class="admin-label">Product Description</label>
        <input
          type="text"
          class="form-control"
          id="description"
          value={productDescription}
          onChange={descriptionHandler}
          required
        />
        <label class="admin-label">Manufacturer</label>
        <input
          type="text"
          class="form-control"
          id="manufacturer"
          value={product_manufacturedBy}
          onChange={manufacturedByHandler}
          required
        />
        <label class="admin-label">Product Image Url </label>
        <input
          type="text"
          class="form-control"
          id="image-url"
          value={image}
          onChange={imageHandler}
          required
        />
      </form>
      <button class="btn btn-primary" onClick={() => formHandler(productTitle)}>
        Submit
      </button>
    </div>
  );
}
export default AdminEditPage