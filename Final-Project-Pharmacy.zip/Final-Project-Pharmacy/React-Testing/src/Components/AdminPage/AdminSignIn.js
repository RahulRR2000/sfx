
import { NavLink } from "react-router-dom";
import axios from "axios";
import "./AdminSignIn.css";
import {
  Avatar,
  Grid,
  Paper,
  TextField,
  Button,
  Typography,
  Link,
} from "@material-ui/core";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { useHistory } from "react-router";

import { useSelector, useDispatch } from "react-redux";
import { adminActions } from "../../store/reduxStore";
const AdminSignIn=()=>{
    const dispatch = useDispatch();

  const routerHistory = useHistory();
const username=useSelector((state)=>state.adminDetails.username)
const password=useSelector((state)=>state.adminDetails.password)


  const handleUsernameChange = (e) => {
  
    dispatch(adminActions.setUsername(e.target.value))
  };
  const handlePasswordChange = (e) => {
    
    dispatch(adminActions.setPassword(e.target.value))
  };
  const handleSubmit=()=>{
    
        
 axios.get(`http://localhost:3004/api/adminLogin/${username}/${password}`)
 .then((response)=>{
     if(response.data.status==="success")
     {
          document.getElementById("error").className = "valid-credentials";
         routerHistory.push("/AdminHomePage")
     }
     else
     {
          document.getElementById("error").className = "invalid-credentials";  
     }
 })
 .catch((err)=>{
     console.log(err)

 })
  }
    return (
      <Grid>
        <Paper elevation={10} className="paperStyle">
          <Grid align="center">
            <Avatar className="avatarstyle">
              <LockOutlinedIcon />
            </Avatar>
            <h2>Sign in</h2>
          </Grid>
          <p id="error" class="valid-credentials">
            Invalid Credentials
          </p>
          <TextField
            label="Username"
            id="username"
            placeholder="Enter username"
            fullWidth
            name="username"
            onChange={handleUsernameChange}
            required
          />
          <TextField
            label="Password"
            id="password"
            placeholder="Enter password"
            type="password"
            name="password"
            fullWidth
            onChange={handlePasswordChange}
            required
          />
          <FormControlLabel
            control={<Checkbox name="checked8" color="primary" />}
            label="Remember me"
          />
          <Button
            type="submit"
            color="primary"
            varient="contained"
            className="btnstyle"
            fullWidth
            onClick={handleSubmit}
          >
            Sign in
          </Button>
          <Typography>
            {" "}
            Do you have an account ?
            <NavLink className="nav-link" exact to="/SignUp">
              Sign Up
            </NavLink>
          </Typography>
        </Paper>
      </Grid>
    );
}
export default AdminSignIn;