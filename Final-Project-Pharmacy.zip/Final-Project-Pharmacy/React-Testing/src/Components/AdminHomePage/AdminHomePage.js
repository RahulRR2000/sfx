import { useSelector, useDispatch} from "react-redux"
import ImmunityBooster from "../../assets/Immunity_Booster.jpg";
import HandSanitizer from "../../assets/Hand sanitizer.jpg";
import PatanjaliHandwash from "../../assets/Patanjali Handwash.jpg";
import InfraredThermometer from "../../assets/Infrared Thermometer.jpg"; 
import HairOil from "../../assets/Hair oil.jpg";
import HimalayaUnderEyeCream from "../../assets/Himalaya Under Eye Cream.jpg";
import AromaShowerGel from "../../assets/Aroma Shower Gel.jpg";
import KlairRichMoistSoothingCream from "../../assets/Klair Rich Moist Smoothing Cream.jpg"; 
import Crocin120 from "../../assets/Crocin 120.jpg";
import Dolo650 from "../../assets/Dolo 650.jpg";
import ANGLOPAR100mg from "../../assets/ANGLOPAR 100MG.jpg";
import IPhytoral from "../../assets/I-Phytoral.jpg"; 
import NoImage from "../../assets/No Image.png"
import axios from "axios"
import './adminHomePage.css'
import {NavLink} from "react-router-dom"
import { productSpecificationActions,productActions} from "../../store/reduxStore";

const AdminHomePage=()=>{

const products=useSelector((state)=>state.products.products)
 const images = [
   { title: "Crocin 120", source: Crocin120 },
   { title: "Dolo 650", source: Dolo650 },
   {
     title: "ANGLOPAR 100mg",
     source: ANGLOPAR100mg,
   },
   { title: "I-Phytoral", source: IPhytoral },
   { title: "Hair Oil", source: HairOil },
   { title: "Aroma Shower Gel", source: AromaShowerGel },
   {
     title: "Klairs Rich Moist Soothing Cream 60 ml",
     source: KlairRichMoistSoothingCream,
   },
   { title: "Under Eye Cream", source: HimalayaUnderEyeCream },
   { title: "Immunity Booster", source: ImmunityBooster },
   { title: "Infrared Thermometer", source: InfraredThermometer },
   { title: "Hand sanitizer", source: HandSanitizer },
   { title: "Patanjali Handwash", source: PatanjaliHandwash },
 ];
 const dispatch=useDispatch()
  const flag = useSelector((state) => state.products.flag);
if (flag === 0) {
  axios.get("http://localhost:3004/api/Getproducts").then((response) => {
    if (response.data.status === "success") {
      try {
        dispatch(productActions.setProducts(response.data.data));

        dispatch(
          productActions.setWellnessProducts(
            products.filter((product) => product.category === "wellness")
          )
        );
        dispatch(
          productActions.setBeautyProducts(
            products.filter((product) => product.category === "beauty")
          )
        );
        dispatch(
          productActions.setMedicineProducts(
            products.filter((product) => product.category === "Medicine")
          )
        );
      
      } catch (err) {
        console.log(err);
      }

      dispatch(productActions.setFlag());
    }
  })
  
}
    const viewHandler = (product) => {
      axios
        .get(`http://localhost:3004/api/Getproduct/${product}`)
        .then((response) => {
          if (response.data.status === "success") {
            dispatch(
              productSpecificationActions.setProduct_title(
                response.data.data.product
              )
            );
            dispatch(
              productSpecificationActions.setProduct_category(
                response.data.data.category
              )
            );
            dispatch(
              productSpecificationActions.setProduct_price(
                response.data.data.price
              )
            );
            dispatch(
              productSpecificationActions.setProduct_description(
                response.data.data.description
              )
            );
            dispatch(
              productSpecificationActions.setProduct_image(
                response.data.data.image
              )
            );
            dispatch(
              productSpecificationActions.setProduct_manufacturedBy(
                response.data.data.manufacturedBy
              )
            );
          } else {
            dispatch(productSpecificationActions.setProduct_title("none"));
          }
        });
    };
const deleteHandler=(product) =>{
  axios.delete(`http://localhost:3004/api/deleteProduct/${product}`)
  .then((response)=>{
    axios.get("http://localhost:3004/api/Getproducts").then((response) => {
      if (response.data.status === "success") {
        try {
          dispatch(productActions.setProducts(response.data.data));
        } catch (err) {
          console.log(err);
        }
      }
    });
  })
}
    return (
      <div id="outer-div">
        <div class="row">
          <h4 class="heading">All Products</h4>
          <NavLink to="/addProducts">
            <button class="btn btn-warning">Add Products</button>
          </NavLink>
          {products.map((product) => (
            <div class="card col-md-2 col-11" key={product._id}>
              <div id="medicine-zoom" class="zoom">
                <img
                  id="card-image"
                  src={
                    images.filter(
                      (image) => image.title === product.product
                    )[0] === undefined
                      ? NoImage
                      : images.filter(
                          (image) => image.title === product.product
                        )[0].source
                  }
                  class="card-img-top"
                  alt="..."
                />
              </div>
              <div class="card-body">
                <h5 class="card-title">{product.product}</h5>
                <h6 class="text-muted card-title">Price: {product.price}</h6>

                <p class="card-text">
                  <small class="text-muted">4 left in stock</small>
                </p>
                <div class="text-center">
                  <button 
                    onClick={() => deleteHandler(product.product)}
                    class="btn btn-warning admin-btn"
                  >
                    Delete
                  </button>
                  <NavLink to="/AdminEditPage">
                    <button
                      onClick={() => viewHandler(product.product)}
                      class="btn btn-warning admin-btn"
                    >
                      Edit
                    </button>
                  </NavLink>
                </div>
                
              </div>
            </div>
          ))}
        </div>
      </div>
    );
}
export default AdminHomePage