import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { productActions } from "../../store/reduxStore";
import {NavLink} from "react-router-dom"

const AddProducts=()=>{
    const flag= useSelector((state)=>state.products.flag)
            
   const dispatch=useDispatch()            
    const formHandler=(event)=>{
        event.preventDefault()
        let form=document.getElementById("product-form").elements;
        let product=form["title"].value
        let category=form["category"].value
        let price=form["price"].value
        let description=form["description"].value
        let manufacturedBy=form["manufacturer"].value
        let image=form["image-url"].value
 console.log(product)
        let productDetails={
            product,
            category,
            price,
            description,
            manufacturedBy,
            image
        }
        axios.post("http://localhost:3004/api/Addproducts",productDetails)
        .then((response)=>{
            if(response.data.status==="success")
            {
                console.log("product added successfully")
                dispatch(productActions.clearAllProducts())
        axios.get("http://localhost:3004/api/Getproducts").then((response) => {
     if (response.data.status === "success") {
      try {
        dispatch(productActions.setProducts(response.data.data));
      }
      catch(err)
    {
        console.log(err)
    }
     }
    })
            }    
        })
        .catch((err)=>{
            console.log(err)
        })
    }
    
    return (
      <div>
        <NavLink to="/AdminHomePage">
          <button class="btn btn-warning">Go to Home page</button>
        </NavLink>
        <form onSubmit={formHandler} id="product-form">
          <label>Product Title</label>
          <input type="text" class="form-control" id="title" />
          <label>Product Category</label>
          <input type="text" class="form-control" id="category" />
          <label>Product Price</label>
          <input type="number" class="form-control" id="price" />
          <label>Product Description</label>
          <input type="text" class="form-control" id="description" />
          <label>Manufacturer</label>
          <input type="text" class="form-control" id="manufacturer" />
          <label>Product Image Url </label>
          <input type="text" class="form-control" id="image-url" />
          <button class="btn btn-primary" type="submit">
            Submit
          </button>
        </form>
      </div>
    );
}
export default AddProducts;