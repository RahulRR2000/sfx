
import {
  Grid,
  Paper,
  Avatar,
  Typography,
  TextField,
  Button,
} from "@material-ui/core";
//import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';
import {useHistory} from 'react-router-dom';
import './signUp.css';
import {useState} from 'react'
import axios from "axios";
import { userActions } from "../../store/reduxStore";
import { useSelector, useDispatch } from "react-redux";
const Signup = () => {
    const routerHistory=useHistory();
const [confirmPassword,setConfirmPassword]=useState('')
const dispatch= useDispatch()
const usernameHandler = (event) => {
  dispatch(userActions.setUsername(event.target.value))
  };
  const phoneNumberHandler = (event) => {
    dispatch(userActions.setPhoneNumber(event.target.value))
  };
  const emailHandler = (event) => {
    dispatch(userActions.setEmail(event.target.value));
  };
const passwordHandler=(e)=>{
    
 dispatch(userActions.setPassword(e.target.value))
}
const confirmPasswordHandler=(e)=>{
    setConfirmPassword(e.target.value);
}
const username=useSelector((state) => state.userDetails.username);
const password=useSelector((state)=> state.userDetails.password)
const phoneNumber=useSelector((state)=> state.userDetails.phoneNumber)
const email=useSelector((state)=>state.userDetails.email)
const formHandler = (event) => {
  event.preventDefault();

  let flag = 0;
  let namePattern = /^[a-zA-Z]+$/;
  let pattern = /^([+]?\d{2})?\d{10}$/;
  let emailPattern = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
  console.log(username)
  if (!phoneNumber.match(pattern) || phoneNumber.trim() === "") {
    flag = 1;
   
     document.getElementById("phonenumberdiv").className = "is-invalid";
      document.getElementById("error").className = "invalid-credentials";

  } else { 
   
     document.getElementById("phonenumberdiv").className = "valid";
      document.getElementById("error").className = "valid-credentials";
  }
  if (
    username.trim().length < 4 ||
    username.trim() === "" ||
    !username.match(namePattern)) {
    flag = 1;
    document.getElementById("error").className="invalid-credentials"
   document.getElementById("usernamediv").className = "is-invalid";
  } else {
    document.getElementById("error").className = "valid-credentials";
    document.getElementById("usernamediv").className = "valid";
  }
  if (!email.trim().match(emailPattern) || email.trim() === "") {
    flag = 1;
     document.getElementById("error").className="invalid-credentials"
    document.getElementById("emaildiv").className = "is-invalid";
  } else {
     document.getElementById("error").className="valid-credentials"
     document.getElementById("emaildiv").className = "valid";
   console.log()
  }
  if(password.trim()!==''&&password===confirmPassword && flag=== 0)
  {
     document.getElementById("error").className = "valid-credentials";
       document.getElementById("passworddiv").className = "valid";
       document.getElementById("confirmpassworddiv").className = "valid";
       let user={
           username,
           password,
           phoneNumber


       }
      axios.post("http://localhost:3004/api/SignUp",user).then((response)=>{
          if(response.data.status==='success')
          {
              document.getElementById("phonenumberdiv").className="valid";
                           document.getElementById("error").className =
                             "valid-credentials";
                          dispatch(userActions.clearAllData())
              routerHistory.push("/");
          }
          else
          {
              console.log('fail in signup')
              document.getElementById("phonenumberdiv").className="is-invalid";
              document.getElementById("error").className="invalid-credentials"
              flag=1;
              
          }
      }).catch((err)=>{
          console.log(err);
      });
  }
  else{
    flag=1;
     document.getElementById("error").className = "invalid-credentials";
      document.getElementById("passworddiv").className="is-invalid"
      document.getElementById("confirmpassworddiv").className="is-invalid";
  }
  if (flag === 0) {
   
    console.log("ok");
  }
};

  
 
  const headerStyle = { margin: 0 };
 
  return (
    <Grid>
      <Paper elevation={20} className="paperStyle">
        <Grid align="center">
          <Avatar className="avatarstyle"></Avatar>
          <h2 style={headerStyle}>Sign Up</h2>
          <Typography variant="caption" gutterBottom>
            please fill this form to create an account
          </Typography>
        </Grid>
      
      <p id="error" className="valid-credentials">Invalid credentials</p>
        <form>
            <div id="usernamediv">
          <TextField  fullWidth onChange={usernameHandler} label="Name" id="username" placeholder="username" /></div>
          
          <div id="emaildiv"><TextField  fullWidth onChange={emailHandler} label="Email"  id="email" /></div>
          <div id="phonenumberdiv"><TextField fullWidth onChange={phoneNumberHandler} type="number" label="Phone Number" id="phoneNumber"/></div>
          <div id="passworddiv"><TextField type="password" fullWidth label="Password" id="password" onChange={passwordHandler} /></div>
          <div id="confirmpassworddiv"><TextField fullWidth type="password" label="Confirm Password" id="confirmPassword" onChange={confirmPasswordHandler}/></div>
        
          <Button type="submit" variant="contained" color="primary" className="btn1" onClick={formHandler}>
            Sign Up
          </Button>
        </form>
        <small className="text-muted display-block">*No two users can have same Phone Number</small>
        
      </Paper>
    </Grid>
  );
};
export default Signup;
