
import { useSelector,useDispatch } from 'react-redux';
import {NavLink} from 'react-router-dom';
import { useHistory} from 'react-router-dom';
import { userActions,productSpecificationActions,productActions } from '../../store/reduxStore';
import axios from 'axios'
import "./Header.css";
import SignIn from "../../Components/SignIn/SignIn"

const Header= () =>{
   const router = useHistory();
const dispatch=useDispatch();
 const username=useSelector((state) => (state.userDetails.username))
 let cart=useSelector((state)=>state.userDetails.cart)
const cartLinkHandler=(event)=>{


axios.get(`http://localhost:3004/api/cart/${username}`)
      .then((response)=>{
        if(response.data.status==='success')
        {
        console.log('success')
       dispatch(userActions.setCart(response.data.data));
        }
      })
router.push("/Cart")

}
const orderLinkHandler=(event)=>{
  event.preventDefault()
  axios.get(`http://localhost:3004/api/getOrders/${username}`).then((response) => {
    if (response.data.status === "success") {
      console.log("success");
      dispatch(userActions.setOrder(response.data.data));
    }
  });
  router.push("/Orders");
}
const wishesLinkHandler = () => {
  
  axios
    .get(`http://localhost:3004/api/getWishes/${username}`)
    .then((response) => {
      if (response.data.status === "success") {
        console.log("success");
        dispatch(userActions.setWishes(response.data.data));
      }
    });
  router.push("/Wishes");
};
const signoutHandler=()=>{
  dispatch(userActions.clearAllData())
  dispatch(productActions.clearAllProducts())
}
const searchBoxHandler=()=>{
  let value=document.getElementById("search").value;
  let arr=value.split(' ');
  console.log(arr);
  value="";
  arr.map((element)=>{
   element= element.charAt(0).toUpperCase() + element.slice(1);
   value+=element+" "
})
value.trim();
  console.log(value)
   axios.get(`http://localhost:3004/api/Getproduct/${value}`)
   .then((response)=>{
if(response.data.status==='success')
{
   dispatch(
     productSpecificationActions.setProduct_title(response.data.data.product)
   );
   dispatch(
     productSpecificationActions.setProduct_category(
       response.data.data.category
     )
   );
   dispatch(
     productSpecificationActions.setProduct_price(response.data.data.price)
   );
   dispatch(
     productSpecificationActions.setProduct_description(
       response.data.data.description
     )
   );
   dispatch(
     productSpecificationActions.setProduct_image(response.data.data.image)
   );
router.push("/Specifications");
  }

   })
   .catch((err) =>{
     console.log(err)
   })
  }
        return (
          <nav
            id="header"
            className="navbar navbar-expand-lg navbar-light bg-light"
          >
            <div className="container-fluid">
              <span className="navbar-brand">
                <i class="fas fa-clinic-medical"></i>
              </span>
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarScroll"
                aria-controls="navbarScroll"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse " id="navbarScroll">
                <ul className="navbar-nav  my-2 my-lg-0 mx-auto navbar-nav-scroll">
                  <li classname="nav-item">
                    <NavLink className=" mx-3 nav-link" to="/Home">
                      Home
                    </NavLink>
                  </li>
                  <li class="nav-item">
                    <NavLink className="nav-link mx-3" to="/MedicinesPage">
                      Medicines <i class="fas fa-capsules"></i>
                    </NavLink>
                  </li>

                  <li class="nav-item">
                    <NavLink className="nav-link mx-3" to="/BeautyPage">
                      Beauty <i class="fas fa-spa"></i>
                    </NavLink>
                  </li>
                  <li class="nav-item">
                    <NavLink className="nav-link mx-3" to="/WellnessPage">
                      Wellness <i class="fas fa-heartbeat"></i>
                    </NavLink>
                  </li>
                  <li class="nav-item">
                    <NavLink
                      className="nav-link mx-3"
                      to="/Cart"
                      onClick={cartLinkHandler}
                    >
                      Cart <i class="fas fa-shopping-cart"></i>
                    </NavLink>
                  </li>

                  <li class="nav-item">
                    <NavLink
                      className="nav-link mx-3"
                      to="/Wishes"
                      onClick={wishesLinkHandler}
                    >
                      Your Wishes <i class="fa fa-heart" aria-hidden="true"></i>
                    </NavLink>
                  </li>
                  <li class="nav-item">
                    <NavLink
                      className="nav-link mx-3"
                      to="/Orders"
                      onClick={orderLinkHandler}
                    >
                      Your Orders
                    </NavLink>
                  </li>
                </ul>
                <ul className="navbar-nav  my-2 my-lg-0 mx-auto navbar-nav-scroll">
                  <form className="d-flex">
                    <input
                      className="form-control me-2"
                      type="search"
                      placeholder="Search"
                      aria-label="Search"
                      id="search"

                    />
                    <button className="btn btn-outline-success" type="button" onClick={searchBoxHandler}>
                      Search
                    </button>
                  </form>

                  <li class="nav-item">
                    <NavLink className="nav-link mx-3" to="/SignIn" onClick={signoutHandler}>
                      Sign Out <i class="fa fa-sign-out" aria-hidden="true"></i>
                    </NavLink>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        );
    }



export default Header ;