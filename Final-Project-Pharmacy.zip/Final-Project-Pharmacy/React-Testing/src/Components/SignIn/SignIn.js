
import { NavLink } from "react-router-dom";
import axios from "axios";
import {
  Avatar,
  Grid,
  Paper,
  TextField,
  Button,
  Typography,
  Link,
} from "@material-ui/core";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { useHistory } from "react-router";

import { useSelector, useDispatch } from "react-redux";
import {userActions, authActions} from '../../store/reduxStore'
import  "./signIn.css"
const SignIn = () => {
 
  const dispatch = useDispatch();

  const routerHistory = useHistory();


  const handleUsernameChange = (e) => {
  
    dispatch(userActions.setUsername(e.target.value))
  };
  const handlePasswordChange = (e) => {
    
    dispatch(userActions.setPassword(e.target.value))
  };
   const username = useSelector((state) => state.userDetails.username);
   const password = useSelector((state) => state.userDetails.password);
   const phoneNumber = useSelector((state) => state.userDetails.phoneNumber);
const cartshop=useSelector((state) => state.userDetails.cart)
   console.log(phoneNumber+"*");
  console.log(cartshop[0])
   const handleSubmit = (e) => {
    e.preventDefault();
    const users = {
      username,
      password,
    };
  


    axios
      .post("http://localhost:3004/api/Login", users)
      .then((response) => {
        if (response.data.status === "success") {
          dispatch(userActions.setUsername(response.data.data.username))
          dispatch(userActions.setPassword(response.data.data.password));
          dispatch(userActions.setPhoneNumber(response.data.data.phoneNumber))
          dispatch(authActions.login())
          document.getElementById("error").className="valid-credentials";
          routerHistory.push("/Home");
        } else {
          console.log(response.data.status);
        document.getElementById("error").className="invalid-credentials";  
          dispatch(userActions.logout())
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  return (
    <Grid>
      <Paper elevation={10} className="paperStyle">
        <Grid align="center">
          <Avatar className="avatarstyle">
            <LockOutlinedIcon />
          </Avatar>
          <h2>Sign in</h2>
        </Grid>
        <p id="error" class="valid-credentials">Invalid Credentials</p>
        <TextField
          label="Username"
          id="username"
          placeholder="Enter username"
          fullWidth
          name="username"
          
          onChange={handleUsernameChange}
          required
        />
        <TextField
          label="Password"
          id="password"
          placeholder="Enter password"
          type="password"
        
          name="password"
          fullWidth
          onChange={handlePasswordChange}
          required
        />
        <FormControlLabel
          control={<Checkbox name="checked8" color="primary" />}
          label="Remember me"
        />
        <Button
          type="submit"
          color="primary"
          varient="contained"
          className="btnstyle"
          fullWidth
          onClick={handleSubmit}
        >
          Sign in 
        </Button>
        <Typography>
          {" "}
          Do you have an account ?
          <NavLink className="nav-link" exact to="/SignUp">
            Sign Up
          </NavLink>
        </Typography>
      </Paper>
    </Grid>
  );
};

export default SignIn;
