import React from "react";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import App from "../App";
import Home from "../Pages/HomePage/Home";
import SignUp from '../Components/SignUp/SignUp'
import Wellness from '../Components/Wellness/Wellness'
import Beauty from '../Components/Beauty/Beauty' 
import Specifications from "../Components/Specifications/Specifications";
import CartPage from '../Pages/CartPage/CartPage'
import MedicinePage  from "../Pages/MedicinePage/MedicinePage";
//import CartSample from '../Components/Cart-sample/CartSample'
import PaymentPage from '../Pages/PaymentPage/PaymentPage'
import WellnessPage from "../Pages/wellnessPage/WellnessPage";
import OrdersPage  from "../Pages/OrdersPage/OrdersPage";
import OrderPlaced  from "../Pages/PaymentPage/OrderPlaced";
import BeautyPage from "../Pages/BeautyPage/BeautyPage";
import SignIn from "../Components/SignIn/SignIn"
import WishesPage from "../Pages/Wishes/WishesPage";
import AdminSignIn from "../Components/AdminPage/AdminSignIn";
import AdminHomePage from "../Components/AdminHomePage/AdminHomePage";
import AddProducts from "../Components/AddProducts/AddProducts"
import AdminEditPage from "../Components/AdminEditPage/AdminEditPage";
const Routing = ()=>{
    return (
      <div>
        <Router>
          <div>
            <Switch>
              <Route exact path="/" component={App} />
              <Route path="/Home" component={Home} />
              <Route path="/SignUp" component={SignUp} />
              <Route path="/SignIn" component={SignIn}/>
              <Route path="/Wellness" component={Wellness} />
              <Route path="/Specifications" component={Specifications} />
              <Route path="/MedicinesPage" component={MedicinePage} />
              <Route path="/Beauty" component={Beauty} />
              <Route path="/Cart" component={CartPage} />
              <Route path="/Orders" component={OrdersPage}/>
              <Route path="/Payment" component={PaymentPage}/>
            <Route path="/OrderPlaced" component={OrderPlaced}/>
            <Route path="/WellnessPage" component={WellnessPage}/>
            <Route path="/BeautyPage" component={BeautyPage}/>
          <Route path="/Wishes" component={WishesPage}/>
            <Route path="/AdminSignIn" component={AdminSignIn}/>
           <Route path="/AdminHomePage" component={AdminHomePage}/>
           <Route path="/AddProducts" component={AddProducts}/>
           <Route path="/AdminEditPage" component={AdminEditPage}/>
            </Switch>
          </div>
        </Router>
      </div>
    );
}
export default Routing;
